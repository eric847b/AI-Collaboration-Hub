// ==UserScript==
// @name         19. Caching Strategies .M
// @namespace    http://tampermonkey.net/
// @version      2026.04.28.0
// @description  Advanced caching strategies for AI chat with TTL support
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://perplexity.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(function() {
  'use strict';

  class AIRMDCachingStrategiesModule {
    constructor() {
      this.name = 'AIRMDCachingStrategies';
      this.version = '2026.03.28.1';
      this.dependencies = [];
      this.critical = false;
      this.config = {
        cleanupIntervalMs: 0
      };
      this.cache = new Map();
      this.pendingLoads = new Map();
      this._cleanupTimer = null;
      this.api = {
        setCache: (key, value, ttl) => this.setCache(key, value, ttl),
        getCache: (key) => this.getCache(key),
        getOrLoad: (key, loader, ttl) => this.getOrLoad(key, loader, ttl),
        invalidate: (key) => this.invalidate(key),
        clearExpired: () => this.clearExpired(),
        clearAll: () => this.clearAll(),
        getStats: () => this.getStats(),
        distributedCachingInfo: () => this.distributedCachingInfo(),
        init: () => this.initApi()
      };
    }

    init() {
      if (window.ConfigManager && typeof window.ConfigManager.getConfig === 'function') {
        this.config = {
          ...this.config,
          ...window.ConfigManager.getConfig('airmdcachingstrategies')
        };
      }

      window.AIRMDCachingStrategies = this.api;
      return this.api;
    }

    execute() {
      this.startCleanupTimer();
    }

    onConfigUpdate(settings) {
      Object.assign(this.config, settings);
      this.startCleanupTimer();
    }

    startCleanupTimer() {
      if (this._cleanupTimer) {
        clearInterval(this._cleanupTimer);
        this._cleanupTimer = null;
      }

      if (this.config.cleanupIntervalMs > 0) {
        this._cleanupTimer = setInterval(() => this.clearExpired(), this.config.cleanupIntervalMs);
      }
    }

    setCache(key, value, ttl = 0) {
      const expiresAt = ttl > 0 ? Date.now() + ttl : 0;
      this.cache.set(key, { value, expiresAt });
      return value;
    }

    getCache(key) {
      const cached = this.cache.get(key);
      if (!cached) {
        return null;
      }

      if (cached.expiresAt && cached.expiresAt <= Date.now()) {
        this.cache.delete(key);
        return null;
      }

      return cached.value;
    }

    getOrLoad(key, loader, ttl = 0) {
      const cached = this.getCache(key);
      if (cached !== null) {
        return Promise.resolve(cached);
      }

      if (this.pendingLoads.has(key)) {
        return this.pendingLoads.get(key);
      }

      const pending = Promise.resolve()
        .then(() => loader())
        .then((value) => {
          this.setCache(key, value, ttl);
          this.pendingLoads.delete(key);
          return value;
        })
        .catch((error) => {
          this.pendingLoads.delete(key);
          throw error;
        });

      this.pendingLoads.set(key, pending);
      return pending;
    }

    invalidate(key) {
      this.pendingLoads.delete(key);
      return this.cache.delete(key);
    }

    clearExpired() {
      let removed = 0;

      this.cache.forEach((entry, cacheKey) => {
        if (entry.expiresAt && entry.expiresAt <= Date.now()) {
          this.cache.delete(cacheKey);
          removed += 1;
        }
      });

      return removed;
    }

    clearAll() {
      this.pendingLoads.clear();
      this.cache.clear();
    }

    getStats() {
      return {
        entries: this.cache.size,
        pendingLoads: this.pendingLoads.size
      };
    }

    distributedCachingInfo() {
      return 'Distributed caching requires a server-side store and is not implemented in this userscript.';
    }

    initApi() {
      this.startCleanupTimer();
      return this.getStats();
    }

    destroy() {
      if (this._cleanupTimer) {
        clearInterval(this._cleanupTimer);
        this._cleanupTimer = null;
      }

      this.clearAll();
    }
  }

  const instance = new AIRMDCachingStrategiesModule();
  window.AIRMDCachingStrategiesModule = instance;
  
  // ✅ Legacy RMD Compatibility - Integrated
  const LEGACY_METHOD_ALIASES = {
    airmdInitCachingStrategies: "init",
    airmdSetCache: "setCache",
    airmdGetCache: "getCache",
    airmdGetOrLoad: "getOrLoad",
    airmdInvalidateCache: "invalidate",
    airmdClearExpiredCache: "clearExpired",
    airmdClearAllCache: "clearAll",
    airmdGetCacheStats: "getStats",
    airmdDistributedCachingInfo: "distributedCachingInfo"
  };

  // Register legacy method aliases for backwards compatibility
  Object.entries(LEGACY_METHOD_ALIASES).forEach(([alias, methodName]) => {
    if (!window[alias] && typeof instance.api[methodName] === "function") {
      window[alias] = (...args) => instance.api[methodName](...args);
    }
  });

  if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
    window.ModuleRegistry.register(instance);
    
    // Also register legacy module name for compatibility
    try {
      const LegacyModule = class {
        constructor() {
          this.name = "19-rmd-caching-strategies";
          this.version = "2026.04.10.1";
          this.dependencies = [];
          this.critical = false;
        }
        init() {
          instance.init();
          return true;
        }
      };
      window.ModuleRegistry.register(new LegacyModule());
    } catch(e) {}
  } else if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
    window.ChatGPTModules.register(instance);
  } else {
    instance.init();
    instance.execute();
  }
})();
