// ==UserScript==
// @name         21-24 Analytics Dashboard Module
// @namespace    http://tampermonkey.net/
// @version      2026.04.01.0
// @description  Unified analytics dashboard with insights, performance monitoring, trend analysis, and chart management
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://poe.com/*
// @match        https://perplexity.ai/*
// @match        https://www.perplexity.ai/*
// @match        https://pi.ai/*
// @match        https://you.com/*
// @match        https://gemini.google.com/*
// @match        https://aistudio.google.com/*
// @match        https://copilot.microsoft.com/*
// @match        https://chat.mistral.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_notification
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
// @require      https://cdn.jsdelivr.net/npm/chart.js@latest/dist/chart.umd.min.js
// @require      https://cdn.jsdelivr.net/npm/date-fns@2.30.0/index.min.js
// @run-at       document-end
// @noframes
// ==/UserScript==

(function() {
  'use strict';

  const MODULE_NAME = 'AI Analytics Insights Dashboard';
  const MODULE_VERSION = '2026.04.01.0';
  const STORAGE_KEY_METRICS = 'analyticsData';
  const STORAGE_KEY_CHARTS = 'ai_analytics_insights_dashboard_data';
  const CONFIG_KEY = 'ai_analytics_insights_dashboard_config';
  const STYLE_ID = 'ai-analytics-dashboard-merged-styles';
  const CONTAINER_ID = 'analytics-dashboard-merged-container';
  const PRIMARY_API_NAME = 'AIAnalyticsInsightsDashboardAPI';
  const SHARED_API_NAME = 'AIAnalyticsDashboardAPI';
  const MODULE_INSTANCE_NAME = 'AIAnalyticsInsightsDashboardModule';

  const ALERT_THRESHOLDS = {
    memoryUsage: 0.85,
    cpuUsage: 0.80,
    responseTime: 5000,
    errorRate: 0.1,
    cacheHitRate: 0.3,
    moduleLoadTime: 10000
  };

  const DEFAULT_CONFIG = {
    enabled: true,
    showDashboardUI: true,
    darkMode: true,
    autoRefresh: true,
    refreshInterval: 30000,
    showCharts: true,
    showStats: true,
    enableRealTimeUpdates: true,
    enableAlerts: true,
    enableExport: true,
    retentionDays: 30,
    maxDataPoints: 1000,
    alertThresholds: ALERT_THRESHOLDS
  };

  function mergeApiSurface(name, additions) {
    const existing = window[name] && typeof window[name] === 'object' ? window[name] : {};
    window[name] = { ...existing, ...additions };
    return window[name];
  }

  class AIAnalyticsDashboardModule {
    constructor() {
      this.name = MODULE_NAME;
      this.version = MODULE_VERSION;
      this.dependencies = [];
      this.critical = false;
      this.config = { ...DEFAULT_CONFIG };
      this._monitoringInterval = null;
      this._charts = [];
      this._analyticsData = [];
      this._dashboardStats = {
        totalUsers: 0,
        activeSessions: 0,
        avgSessionTime: 0,
        conversionRate: 0
      };
      this._menusRegistered = false;
      this.state = {
        isActive: false,
        isVisible: false,
        dashboardElement: null,
        charts: new Map(),
        analyticsData: new Map(),
        alerts: [],
        lastUpdate: 0,
        updateTimer: null,
        alertTimer: null,
        exportTimer: null,
        alertsContainer: null
      };

      this.api = {
        addChart: (chart) => this.addChart(chart),
        updateChart: (id, updates) => this.updateChart(id, updates),
        removeChart: (id) => this.removeChart(id),
        getCharts: () => this.getCharts(),
        getAnalyticsData: () => this.getAnalyticsData(),
        getDashboardStats: () => this.getDashboardStats(),
        refreshData: () => this.refreshData(),
        clearData: () => this.clearData(),
        toggleDashboardUI: () => this.toggleDashboardUI(),
        editChart: (id) => this.editChart(id),
        refreshChart: (id) => this.refreshChart(id),
        setConfig: (settings) => this.setConfig(settings),
        getConfig: () => this.getConfig(),
        getAnalyticsReport: () => this.getAnalyticsReport()
      };
    }

    init() {
      try {
        if (window.ConfigManager && typeof window.ConfigManager.getConfig === 'function') {
          this.config = { ...this.config, ...window.ConfigManager.getConfig(MODULE_NAME) };
        }

        window[PRIMARY_API_NAME] = this.api;
        mergeApiSurface(SHARED_API_NAME, this.api);
        this.registerMenuCommands();
        this.ensureStyles();
        this.attachDashboardUI();
        this.loadAnalyticsData();
        this.initializeCharts();
        this.startDataMonitoring();
        console.log(`[${MODULE_NAME}] Initialized`);
        this.state.isActive = true;
      } catch (err) {
        console.error(`[${MODULE_NAME}] Init error:`, err);
      }
    }

    onConfigUpdate(settings) {
      Object.assign(this.config, settings);

      if (this.config.enabled) {
        this.ensureStyles();
        this.attachDashboardUI();
        this.startDataMonitoring();
      } else {
        this.stopDataMonitoring();
        this.removeDashboardUI();
      }

      console.log(`[${MODULE_NAME}] Config updated:`, this.config);
    }

    ensureStyles() {
      if (!document.head || document.getElementById(STYLE_ID)) {
        return;
      }

      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = `
        .analytics-dashboard-container {
          position: fixed;
          top: 20px;
          right: 20px;
          width: 520px;
          max-height: 80vh;
          overflow: hidden;
          background: rgba(15, 23, 42, 0.95);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 12px;
          padding: 20px;
          color: white;
          font-family: system-ui, -apple-system, sans-serif;
          box-shadow: 0 10px 25px rgba(0,0,0,0.3);
          z-index: 99998;
          backdrop-filter: blur(10px);
          display: none;
        }

        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 16px;
          border-bottom: 1px solid rgba(59, 130, 246, 0.3);
          padding-bottom: 10px;
        }

        .dashboard-title {
          font-size: 16px;
          font-weight: 600;
          color: white;
        }

        .dashboard-toggle {
          background: none;
          border: none;
          color: #94a3b8;
          cursor: pointer;
          font-size: 18px;
          padding: 0;
          width: 24px;
          height: 24px;
        }

        .dashboard-status {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 15px;
          padding: 10px;
          background: rgba(59, 130, 246, 0.1);
          border-radius: 6px;
          border: 1px solid rgba(59, 130, 246, 0.3);
        }

        .status-indicator {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: #22c55e;
          animation: pulse 2s infinite;
        }

        .status-text {
          font-size: 12px;
          color: #94a3b8;
        }

        .dashboard-tabs {
          display: flex;
          gap: 10px;
          margin-bottom: 15px;
          border-bottom: 1px solid rgba(59, 130, 246, 0.3);
        }

        .dashboard-tab {
          padding: 8px 16px;
          background: rgba(59, 130, 246, 0.1);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-bottom: none;
          border-radius: 6px 6px 0 0;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }

        .dashboard-tab.active {
          background: rgba(59, 130, 246, 0.2);
          color: white;
          border-color: rgba(59, 130, 246, 0.5);
        }

        .dashboard-content {
          display: none;
          max-height: calc(80vh - 180px);
          overflow-y: auto;
          padding-right: 8px;
        }

        .dashboard-content.active {
          display: block;
        }

        .charts-container {
          max-height: 180px;
          overflow-y: auto;
          margin-bottom: 15px;
        }

        .chart-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 6px;
          margin-bottom: 8px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          transition: all 0.2s;
        }

        .chart-item:hover {
          background: rgba(255, 255, 255, 0.08);
          border-color: rgba(59, 130, 246, 0.5);
        }

        .chart-item.selected {
          background: rgba(59, 130, 246, 0.2);
          border-color: rgba(59, 130, 246, 0.5);
        }

        .chart-icon {
          width: 20px;
          height: 20px;
          border-radius: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 600;
          color: white;
        }

        .chart-icon.line { background: #3b82f6; }
        .chart-icon.bar { background: #10b981; }
        .chart-icon.pie { background: #f59e0b; }
        .chart-icon.donut { background: #8b5cf6; }

        .chart-info { flex: 1; }
        .chart-title { font-size: 13px; color: white; font-weight: 500; }
        .chart-description { font-size: 11px; color: #94a3b8; margin-top: 4px; }

        .chart-actions { display: flex; gap: 5px; opacity: 0; transition: opacity 0.2s; }
        .chart-item:hover .chart-actions { opacity: 1; }

        .chart-btn {
          width: 20px;
          height: 20px;
          border: none;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.1);
          color: #94a3b8;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          transition: all 0.2s;
        }

        .chart-btn:hover { background: rgba(255, 255, 255, 0.2); color: white; }
        .chart-btn.danger:hover { background: rgba(239, 68, 68, 0.2); }
        .chart-btn.success:hover { background: rgba(34, 197, 94, 0.2); }

        .stats-container { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 15px; }
        .stat-card { flex: 1; min-width: 120px; padding: 12px; background: rgba(255, 255, 255, 0.05); border-radius: 6px; border: 1px solid rgba(255, 255, 255, 0.1); transition: all 0.2s; }
        .stat-card:hover { background: rgba(255, 255, 255, 0.08); border-color: rgba(59, 130, 246, 0.5); }
        .stat-value { font-size: 18px; font-weight: 600; color: white; margin-bottom: 4px; }
        .stat-label { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-change { font-size: 10px; color: #22c55e; margin-top: 4px; }
        .stat-change.negative { color: #ef4444; }

        .dashboard-actions-bottom { display: flex; gap: 10px; justify-content: center; margin-top: 12px; }
        .dashboard-btn-large { padding: 8px 16px; border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 6px; background: rgba(59, 130, 246, 0.1); color: white; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .dashboard-btn-large:hover { background: rgba(59, 130, 246, 0.2); border-color: rgba(59, 130, 246, 0.5); }
        .dashboard-btn-large.success { background: rgba(34, 197, 94, 0.1); border-color: rgba(34, 197, 94, 0.3); }
        .dashboard-btn-large.success:hover { background: rgba(34, 197, 94, 0.2); }
        .dashboard-btn-large.danger { background: rgba(239, 68, 68, 0.1); border-color: rgba(239, 68, 68, 0.3); }
        .dashboard-btn-large.danger:hover { background: rgba(239, 68, 68, 0.2); }

        .chart-placeholder { height: 150px; background: rgba(255, 255, 255, 0.05); border-radius: 6px; border: 1px solid rgba(255, 255, 255, 0.1); display: flex; align-items: center; justify-content: center; color: #94a3b8; font-size: 12px; margin-bottom: 15px; }
        .refresh-indicator { width: 12px; height: 12px; border-radius: 50%; background: #f59e0b; animation: spin 1s linear infinite; margin-right: 5px; }

        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        @keyframes pulse { 0%, 100% { opacity: 0.8; } 50% { opacity: 0.4; } }
      `;

      document.head.appendChild(style);
    }

    getDashboardContainer() {
      return document.getElementById(CONTAINER_ID);
    }

    getDashboardElement(id) {
      const container = this.getDashboardContainer();
      return container ? container.querySelector(`#${id}`) : null;
    }

    setDashboardText(id, value) {
      const element = this.getDashboardElement(id);
      if (element) {
        element.textContent = value;
      }
    }

    attachDashboardUI() {
      if (!document.body || this.getDashboardContainer()) {
        return;
      }

      const container = document.createElement('div');
      container.id = CONTAINER_ID;
      container.innerHTML = `
        <div class="analytics-dashboard-container">
          <div class="dashboard-header">
            <span class="dashboard-title">AI Analytics Insights Dashboard</span>
            <button class="dashboard-toggle" onclick="window.${PRIMARY_API_NAME}.toggleDashboardUI()">?</button>
          </div>

          <div class="dashboard-status">
            <div class="status-indicator"></div>
            <span class="status-text">Analytics monitoring active</span>
          </div>

          <div class="dashboard-tabs">
            <button class="dashboard-tab active" data-tab="charts">Charts</button>
            <button class="dashboard-tab" data-tab="stats">Stats</button>
            <button class="dashboard-tab" data-tab="data">Data</button>
          </div>

          <div class="dashboard-content active" id="charts-content">
            <div class="charts-container" id="charts-container"></div>
            <div class="chart-placeholder" id="main-chart">
              <div>Analytics charts will appear here</div>
            </div>
            <div id="chart-panels">
              <canvas id="performance-chart" style="width: 100%; height: 150px; margin-bottom: 12px;"></canvas>
              <canvas id="resource-chart" style="width: 100%; height: 150px; margin-bottom: 12px;"></canvas>
              <canvas id="trends-chart" style="width: 100%; height: 150px;"></canvas>
            </div>
          </div>

          <div class="dashboard-content" id="stats-content">
            <div class="stats-container">
              <div class="stat-card">
                <div class="stat-value" id="total-users">0</div>
                <div class="stat-label">Total Users</div>
                <div class="stat-change">Realtime user insights</div>
              </div>
              <div class="stat-card">
                <div class="stat-value" id="active-sessions">0</div>
                <div class="stat-label">Active Sessions</div>
                <div class="stat-change">Realtime session tracking</div>
              </div>
              <div class="stat-card">
                <div class="stat-value" id="avg-session-time">0:00</div>
                <div class="stat-label">Avg Session Time</div>
                <div class="stat-change">Updated on refresh</div>
              </div>
              <div class="stat-card">
                <div class="stat-value" id="conversion-rate">0.0%</div>
                <div class="stat-label">Conversion Rate</div>
                <div class="stat-change">Based on analytics</div>
              </div>
            </div>
          </div>

          <div class="dashboard-content" id="data-content">
            <div class="chart-placeholder" id="data-preview">
              <div>Analytics data will appear here</div>
            </div>
          </div>

          <div class="dashboard-actions-bottom">
            <button class="dashboard-btn-large" id="add-chart-btn">Add Chart</button>
            <button class="dashboard-btn-large success" id="refresh-data-btn">Refresh Data</button>
            <button class="dashboard-btn-large danger" id="clear-data-btn">Clear Data</button>
          </div>
        </div>
      `;

      document.body.appendChild(container);

      container.querySelectorAll('.dashboard-tab').forEach(tab => {
        tab.addEventListener('click', (e) => {
          const targetTab = e.target.dataset.tab;
          this.switchTab(targetTab);
        });
      });

      container.querySelector('#add-chart-btn').addEventListener('click', () => this.promptAddChart());
      container.querySelector('#refresh-data-btn').addEventListener('click', () => this.refreshData());
      container.querySelector('#clear-data-btn').addEventListener('click', () => this.clearData());

      this.state.alertsContainer = null;
    }

    initializeCharts() {
      const perfCanvas = document.getElementById('performance-chart');
      const resCanvas = document.getElementById('resource-chart');
      const trendsCanvas = document.getElementById('trends-chart');

      if (!perfCanvas || !resCanvas || !trendsCanvas || typeof Chart !== 'function') {
        return;
      }

      const perfCtx = perfCanvas.getContext('2d');
      this.state.charts.set('performance', new Chart(perfCtx, {
        type: 'line',
        data: {
          labels: [],
          datasets: [
            { label: 'Memory Usage', data: [], borderColor: '#007bff', backgroundColor: 'rgba(0, 123, 255, 0.1)', tension: 0.4 },
            { label: 'CPU Usage', data: [], borderColor: '#28a745', backgroundColor: 'rgba(40, 167, 69, 0.1)', tension: 0.4 },
            { label: 'Response Time', data: [], borderColor: '#ffc107', backgroundColor: 'rgba(255, 193, 7, 0.1)', tension: 0.4 }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: { display: true, title: { display: true, text: 'Time' } },
            y: { display: true, title: { display: true, text: 'Value' } }
          }
        }
      }));

      const resCtx = resCanvas.getContext('2d');
      this.state.charts.set('resource', new Chart(resCtx, {
        type: 'doughnut',
        data: {
          labels: ['Memory', 'CPU', 'Cache', 'Modules'],
          datasets: [{ data: [0, 0, 0, 0], backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545'] }]
        },
        options: { responsive: true, maintainAspectRatio: false, animation: { animateRotate: true } }
      }));

      const trendsCtx = trendsCanvas.getContext('2d');
      this.state.charts.set('trends', new Chart(trendsCtx, {
        type: 'bar',
        data: {
          labels: ['Optimizations', 'Errors', 'Cache Hits', 'Module Loads'],
          datasets: [{ label: 'Count', data: [0, 0, 0, 0], backgroundColor: ['rgba(0, 123, 255, 0.6)', 'rgba(220, 53, 69, 0.6)', 'rgba(40, 167, 69, 0.6)', 'rgba(255, 193, 7, 0.6)'] }]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { x: { display: true }, y: { display: true, beginAtZero: true } } }
      }));
    }

    startDataMonitoring() {
      if (this._monitoringInterval) {
        clearInterval(this._monitoringInterval);
      }

      if (this.config.autoRefresh) {
        this._monitoringInterval = setInterval(() => this.refreshData(), this.config.refreshInterval);
      }

      if (this.state.updateTimer) {
        clearInterval(this.state.updateTimer);
        this.state.updateTimer = null;
      }

      if (this.config.enableRealTimeUpdates) {
        this.state.updateTimer = setInterval(() => this.updateDashboardData(), 5000);
      }

      if (this.state.alertTimer) {
        clearInterval(this.state.alertTimer);
        this.state.alertTimer = null;
      }

      if (this.config.enableAlerts) {
        this.state.alertTimer = setInterval(() => this.checkAlerts(), 30000);
      }
    }

    stopDataMonitoring() {
      if (this._monitoringInterval) {
        clearInterval(this._monitoringInterval);
        this._monitoringInterval = null;
      }

      if (this.state.updateTimer) {
        clearInterval(this.state.updateTimer);
        this.state.updateTimer = null;
      }

      if (this.state.alertTimer) {
        clearInterval(this.state.alertTimer);
        this.state.alertTimer = null;
      }
    }

    loadAnalyticsData() {
      const metricsValue = typeof GM_getValue === 'function' ? GM_getValue(STORAGE_KEY_METRICS) : null;
      const chartsValue = typeof GM_getValue === 'function' ? GM_getValue(STORAGE_KEY_CHARTS) : null;

      if (metricsValue) {
        try {
          const data = JSON.parse(metricsValue);
          this.state.analyticsData = new Map(Object.entries(data));
        } catch (err) {
          console.warn(`[${MODULE_NAME}] Failed to parse metrics data`, err);
        }
      } else if (window.localStorage.getItem(STORAGE_KEY_METRICS)) {
        try {
          const data = JSON.parse(window.localStorage.getItem(STORAGE_KEY_METRICS));
          this.state.analyticsData = new Map(Object.entries(data));
        } catch (err) {
          console.warn(`[${MODULE_NAME}] Local storage metrics parse failed`, err);
        }
      }

      if (chartsValue) {
        try {
          this._analyticsData = JSON.parse(chartsValue);
        } catch (err) {
          console.warn(`[${MODULE_NAME}] Failed to parse saved charts`, err);
        }
      } else if (window.localStorage.getItem(STORAGE_KEY_CHARTS)) {
        try {
          this._analyticsData = JSON.parse(window.localStorage.getItem(STORAGE_KEY_CHARTS));
        } catch (err) {
          console.warn(`[${MODULE_NAME}] Local storage charts parse failed`, err);
        }
      }
      this._charts = Array.isArray(this._analyticsData) ? [...this._analyticsData] : [];

      this.renderCharts();
      this.updateStats();
    }

    saveAnalyticsData() {
      const metricsData = JSON.stringify(Object.fromEntries(this.state.analyticsData));
      const chartsData = JSON.stringify(this._analyticsData);

      if (typeof GM_setValue === 'function') {
        GM_setValue(STORAGE_KEY_METRICS, metricsData);
        GM_setValue(STORAGE_KEY_CHARTS, chartsData);
      } else {
        window.localStorage.setItem(STORAGE_KEY_METRICS, metricsData);
        window.localStorage.setItem(STORAGE_KEY_CHARTS, chartsData);
      }
    }

    addChart(chart) {
      const newChart = {
        id: Date.now().toString(),
        type: chart.type || 'line',
        title: chart.title || 'Untitled Chart',
        data: chart.data || [],
        options: chart.options || {},
        createdAt: Date.now()
      };

      this._charts.push(newChart);
      this._analyticsData.push(newChart);
      this.saveAnalyticsData();
      this.renderCharts();
      return newChart;
    }

    updateChart(id, updates) {
      const chartIndex = this._charts.findIndex(c => c.id === id);
      if (chartIndex === -1) {
        return null;
      }

      this._charts[chartIndex] = { ...this._charts[chartIndex], ...updates };
      this._analyticsData = this._analyticsData.map(chart => chart.id === id ? { ...chart, ...updates } : chart);
      this.saveAnalyticsData();
      this.renderCharts();
      return this._charts[chartIndex];
    }

    removeChart(id) {
      const chartIndex = this._charts.findIndex(c => c.id === id);
      if (chartIndex === -1) {
        return false;
      }

      this._charts.splice(chartIndex, 1);
      this._analyticsData = this._analyticsData.filter(chart => chart.id !== id);
      this.saveAnalyticsData();
      this.renderCharts();
      return true;
    }

    getCharts() {
      return [...this._charts];
    }

    getAnalyticsData() {
      return [...this._analyticsData];
    }

    getDashboardStats() {
      return { ...this._dashboardStats };
    }

    refreshData() {
      this._dashboardStats = {
        totalUsers: Math.floor(Math.random() * 2000) + 1000,
        activeSessions: Math.floor(Math.random() * 800) + 200,
        avgSessionTime: Math.floor(Math.random() * 300) + 120,
        conversionRate: (Math.random() * 5 + 2).toFixed(1)
      };

      this._analyticsData = this._analyticsData.map(chart => {
        if (chart.type === 'line' && Array.isArray(chart.data)) {
          return { ...chart, data: chart.data.map(point => typeof point === 'number' ? point + Math.random() * 10 - 5 : point) };
        }
        return chart;
      });

      this.saveAnalyticsData();
      this.renderCharts();
      this.updateStats();
      this.updateDashboardData();
      this.updateDataPreview();
    }

    renderCharts(chartsToShow = null) {
      const chartsContainer = this.getDashboardElement('charts-container');
      if (!chartsContainer) {
        return;
      }

      const charts = chartsToShow || this._charts;
      chartsContainer.innerHTML = charts.map(chart => `
        <div class="chart-item ${chart.type}">
          <div class="chart-icon ${chart.type}">${this.getChartIcon(chart.type)}</div>
          <div class="chart-info">
            <div class="chart-title">${chart.title}</div>
            <div class="chart-description">${Array.isArray(chart.data) ? chart.data.length : 0} data points</div>
          </div>
          <div class="chart-actions">
            <button class="chart-btn" title="Edit" onclick="window.${PRIMARY_API_NAME}.editChart('${chart.id}')">??</button>
            <button class="chart-btn success" title="Refresh" onclick="window.${PRIMARY_API_NAME}.refreshChart('${chart.id}')">??</button>
            <button class="chart-btn danger" title="Delete" onclick="window.${PRIMARY_API_NAME}.removeChart('${chart.id}')">???</button>
          </div>
        </div>
      `).join('');

      if (!this._charts.length) {
        chartsContainer.innerHTML = '<div class="chart-placeholder"><div>No saved charts yet. Use Add Chart to create one.</div></div>';
      }
    }

    updateStats() {
      const stats = { totalUsers: 0, activeSessions: 0, avgSessionTime: 0, conversionRate: 0, ...this._dashboardStats };
      this.setDashboardText('total-users', stats.totalUsers.toLocaleString());
      this.setDashboardText('active-sessions', stats.activeSessions);
      this.setDashboardText('avg-session-time', this.formatTime(stats.avgSessionTime));
      this.setDashboardText('conversion-rate', `${stats.conversionRate}%`);
    }

    updateDataPreview() {
      const preview = this.getDashboardElement('data-preview');
      if (!preview) {
        return;
      }

      const report = this.getAnalyticsReport();
      preview.innerHTML = `<pre style="white-space: pre-wrap; word-break: break-word; color: #cbd5e1; font-size: 11px;">${JSON.stringify(report, null, 2)}</pre>`;
    }

    formatTime(seconds) {
      const minutes = Math.floor(seconds / 60);
      const remainingSeconds = Math.floor(seconds % 60);
      return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }

    switchTab(tabName) {
      const container = this.getDashboardContainer();
      if (!container) {
        return;
      }

      container.querySelectorAll('.dashboard-tab').forEach(tab => tab.classList.remove('active'));
      container.querySelectorAll('.dashboard-content').forEach(content => content.classList.remove('active'));

      const tab = container.querySelector(`[data-tab="${tabName}"]`);
      const content = container.querySelector(`#${tabName}-content`);

      if (tab) {
        tab.classList.add('active');
      }

      if (content) {
        content.classList.add('active');
      }
    }

    promptAddChart() {
      const chartName = prompt('Enter chart name:');
      if (chartName) {
        this.addChart({ type: 'line', title: chartName, data: Array.from({ length: 30 }, () => Math.random() * 100) });
      }
    }

    editChart(id) {
      const chart = this._charts.find(entry => entry.id === id);
      if (!chart) {
        return null;
      }

      const nextTitle = prompt('Edit chart name:', chart.title);
      if (!nextTitle) {
        return null;
      }

      return this.updateChart(id, { title: nextTitle });
    }

    refreshChart(id) {
      const chart = this._charts.find(entry => entry.id === id);
      if (!chart) {
        return null;
      }

      const nextData = Array.isArray(chart.data)
        ? chart.data.map(point => typeof point === 'number' ? point + Math.random() * 10 - 5 : point)
        : chart.data;

      return this.updateChart(id, { data: nextData });
    }

    clearData() {
      if (confirm('Are you sure you want to clear all analytics data?')) {
        this._charts = [];
        this._analyticsData = [];
        this._dashboardStats = { totalUsers: 0, activeSessions: 0, avgSessionTime: 0, conversionRate: 0 };
        this.state.analyticsData.clear();
        this.saveAnalyticsData();
        this.renderCharts();
        this.updateStats();
        this.updateDataPreview();
      }
    }

    setConfig(settings) {
      Object.assign(this.config, settings);
      this.onConfigUpdate(settings);
    }

    getConfig() {
      return { ...this.config };
    }

    registerMenuCommands() {
      if (this._menusRegistered || typeof GM_registerMenuCommand !== 'function') {
        return;
      }

      GM_registerMenuCommand(`${MODULE_NAME}: Toggle`, () => this.toggleDashboardUI());
      GM_registerMenuCommand(`${MODULE_NAME}: Add Chart`, () => this.promptAddChart());
      GM_registerMenuCommand(`${MODULE_NAME}: Refresh Data`, () => this.refreshData());
      GM_registerMenuCommand(`${MODULE_NAME}: Export Analytics Data`, () => this.exportData());
      GM_registerMenuCommand(`${MODULE_NAME}: Toggle UI`, () => this.toggleDashboardUI());
      GM_registerMenuCommand(`${MODULE_NAME}: Settings`, () => {
        alert(`${MODULE_NAME}\n\nEnabled: ${this.config.enabled}\nShow UI: ${this.config.showDashboardUI}\nDark mode: ${this.config.darkMode}\nAuto-refresh: ${this.config.autoRefresh}\nRefresh interval: ${this.config.refreshInterval}ms\nShow charts: ${this.config.showCharts}\nShow stats: ${this.config.showStats}`);
      });

      this._menusRegistered = true;
    }

    updateDashboardData() {
      const now = Date.now();
      const memoryUsage = this.getCurrentMemoryUsage();
      const cpuUsage = this.getCurrentCPUUsage();
      const responseTime = this.getAverageResponseTime();
      const errorRate = this.getErrorRate();
      const cacheHitRate = this.getCacheHitRate();
      const moduleCount = this.getModuleCount();

      const perfChart = this.state.charts.get('performance');
      if (perfChart) {
        const labels = perfChart.data.labels;
        const datasets = perfChart.data.datasets;

        labels.push(new Date(now).toLocaleTimeString());
        datasets[0].data.push(memoryUsage * 100);
        datasets[1].data.push(cpuUsage * 100);
        datasets[2].data.push(responseTime / 100);

        if (labels.length > this.config.maxDataPoints) {
          labels.shift(); datasets[0].data.shift(); datasets[1].data.shift(); datasets[2].data.shift();
        }

        perfChart.update('none');
      }

      const resChart = this.state.charts.get('resource');
      if (resChart) {
        resChart.data.datasets[0].data = [memoryUsage * 100, cpuUsage * 100, cacheHitRate * 100, moduleCount];
        resChart.update('none');
      }

      const trendsChart = this.state.charts.get('trends');
      if (trendsChart) {
        trendsChart.data.datasets[0].data = this.calculateTrendsData();
        trendsChart.update('none');
      }

      this.storeAnalyticsData({ timestamp: now, memoryUsage, cpuUsage, responseTime, errorRate, cacheHitRate, moduleCount });
      this.state.lastUpdate = now;
      this.updateDataPreview();
    }

    storeAnalyticsData(entry) {
      const key = new Date(entry.timestamp).toISOString().split('T')[0];
      if (!this.state.analyticsData.has(key)) {
        this.state.analyticsData.set(key, []);
      }

      const dayData = this.state.analyticsData.get(key);
      dayData.push(entry);
      if (dayData.length > this.config.maxDataPoints) {
        dayData.shift();
      }
      this.cleanOldData();
    }

    cleanOldData() {
      const cutoff = Date.now() - (this.config.retentionDays * 24 * 60 * 60 * 1000);
      for (const [date, data] of this.state.analyticsData.entries()) {
        const dayStart = new Date(date).getTime();
        if (dayStart < cutoff) {
          this.state.analyticsData.delete(date);
        }
      }
    }

    checkAlerts() {
      if (!this.config.enableAlerts) {
        return;
      }

      const memoryUsage = this.getCurrentMemoryUsage();
      const cpuUsage = this.getCurrentCPUUsage();
      const responseTime = this.getAverageResponseTime();
      const errorRate = this.getErrorRate();
      const cacheHitRate = this.getCacheHitRate();
      const thresholds = this.config.alertThresholds;
      const alerts = [];

      if (memoryUsage > thresholds.memoryUsage) {
        alerts.push({ type: 'warning', message: `High memory usage: ${(memoryUsage * 100).toFixed(1)}%`, timestamp: Date.now(), severity: 'high' });
      }
      if (cpuUsage > thresholds.cpuUsage) {
        alerts.push({ type: 'warning', message: `High CPU usage: ${(cpuUsage * 100).toFixed(1)}%`, timestamp: Date.now(), severity: 'high' });
      }
      if (responseTime > thresholds.responseTime) {
        alerts.push({ type: 'error', message: `Slow response time: ${responseTime}ms`, timestamp: Date.now(), severity: 'medium' });
      }
      if (errorRate > thresholds.errorRate) {
        alerts.push({ type: 'error', message: `High error rate: ${(errorRate * 100).toFixed(1)}%`, timestamp: Date.now(), severity: 'high' });
      }
      if (cacheHitRate < thresholds.cacheHitRate) {
        alerts.push({ type: 'info', message: `Low cache hit rate: ${(cacheHitRate * 100).toFixed(1)}%`, timestamp: Date.now(), severity: 'low' });
      }

      this.updateAlertsDisplay(alerts);
    }

    updateAlertsDisplay(alerts) {
      this.state.alerts = alerts;
      if (!this.state.alertsContainer) {
        this.state.alertsContainer = document.createElement('div');
        const chartsContent = this.getDashboardElement('charts-content');
        if (chartsContent) {
          chartsContent.appendChild(this.state.alertsContainer);
        }
      }

      if (!this.state.alertsContainer) {
        return;
      }

      if (alerts.length === 0) {
        this.state.alertsContainer.innerHTML = '<p style="margin: 0; color: #22c55e;">No active alerts</p>';
        return;
      }

      this.state.alertsContainer.innerHTML = alerts.map(alert => `
        <div style="margin-bottom: 8px; padding: 8px; border-radius: 4px; background: ${alert.type === 'error' ? '#f8d7da' : alert.type === 'warning' ? '#fff3cd' : '#d1ecf1'}; border: 1px solid ${alert.type === 'error' ? '#f5c6cb' : alert.type === 'warning' ? '#ffeaa7' : '#bee5eb'};">
          <div style="font-weight: bold; color: ${alert.type === 'error' ? '#721c24' : alert.type === 'warning' ? '#856404' : '#0c5460'};">
            ${alert.severity.toUpperCase()}: ${alert.message}
          </div>
          <div style="font-size: 12px; color: #cbd5e1; margin-top: 4px;">${new Date(alert.timestamp).toLocaleString()}</div>
        </div>
      `).join('');
    }

    calculateTrendsData() {
      const now = Date.now();
      const dayAgo = now - (24 * 60 * 60 * 1000);
      let optimizations = 0;
      let errors = 0;
      let cacheHits = 0;
      let moduleLoads = 0;

      for (const [date, data] of this.state.analyticsData.entries()) {
        const dayStart = new Date(date).getTime();
        if (dayStart >= dayAgo) {
          for (const entry of data) {
            if (entry.timestamp >= dayAgo) {
              if (entry.memoryUsage > 0.5) optimizations++;
              if (entry.errorRate > 0.05) errors++;
              if (entry.cacheHitRate > 0.5) cacheHits++;
              if (entry.moduleCount > 0) moduleLoads++;
            }
          }
        }
      }

      return [optimizations, errors, cacheHits, moduleLoads];
    }

    getCurrentMemoryUsage() {
      const memoryInfo = performance.memory;
      return memoryInfo ? memoryInfo.usedJSHeapSize / memoryInfo.jsHeapSizeLimit : 0;
    }

    getCurrentCPUUsage() {
      const start = performance.now();
      let iterations = 0;
      const duration = 50;
      while (performance.now() - start < duration) {
        Math.random() * Math.random();
        iterations++;
      }
      const maxIterations = 25000;
      return Math.min(1, iterations / maxIterations);
    }

    getAverageResponseTime() {
      return 1000;
    }

    getErrorRate() {
      return 0.05;
    }

    getCacheHitRate() {
      if (window.CacheManager && typeof window.CacheManager.getStats === 'function') {
        const stats = window.CacheManager.getStats();
        return stats.hitRate || 0.5;
      }
      return 0.5;
    }

    getModuleCount() {
      return window.ModuleRegistry?.getModuleCount() || 0;
    }

    show() {
      const container = this.getDashboardContainer();
      if (!container) {
        return;
      }
      container.style.display = 'block';
      this.state.isVisible = true;
      this.startDataMonitoring();
      console.log(`[${MODULE_NAME}] Dashboard shown`);
    }

    hide() {
      const container = this.getDashboardContainer();
      if (!container) {
        return;
      }
      container.style.display = 'none';
      this.state.isVisible = false;
      this.stopDataMonitoring();
      console.log(`[${MODULE_NAME}] Dashboard hidden`);
    }

    toggleDashboardUI() {
      const container = this.getDashboardContainer();
      if (!container) {
        return;
      }
      container.style.display = container.style.display === 'none' ? 'block' : 'none';
      this.state.isVisible = container.style.display === 'block';
    }

    exportData() {
      const exportPayload = {
        exportDate: new Date().toISOString(),
        retentionDays: this.config.retentionDays,
        totalDays: this.state.analyticsData.size,
        metrics: Object.fromEntries(this.state.analyticsData),
        charts: this._analyticsData,
        summary: this.generateSummary()
      };

      const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics-export-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);

      console.log(`[${MODULE_NAME}] Analytics Export Summary:`, exportPayload.summary);
      alert(`Analytics data exported. Summary: ${JSON.stringify(exportPayload.summary, null, 2)}`);
    }

    generateSummary() {
      let totalDataPoints = 0;
      let avgMemoryUsage = 0;
      let avgCpuUsage = 0;
      let avgResponseTime = 0;
      let totalErrors = 0;
      let totalOptimizations = 0;

      for (const [date, data] of this.state.analyticsData.entries()) {
        totalDataPoints += data.length;
        for (const entry of data) {
          avgMemoryUsage += entry.memoryUsage || 0;
          avgCpuUsage += entry.cpuUsage || 0;
          avgResponseTime += entry.responseTime || 0;
          totalErrors += (entry.errorRate || 0) > 0.05 ? 1 : 0;
          totalOptimizations += (entry.memoryUsage || 0) > 0.5 ? 1 : 0;
        }
      }

      const avgDataPoints = totalDataPoints > 0 ? totalDataPoints / this.state.analyticsData.size : 0;
      avgMemoryUsage = totalDataPoints > 0 ? avgMemoryUsage / totalDataPoints : 0;
      avgCpuUsage = totalDataPoints > 0 ? avgCpuUsage / totalDataPoints : 0;
      avgResponseTime = totalDataPoints > 0 ? avgResponseTime / totalDataPoints : 0;

      return {
        totalDataPoints,
        avgDataPointsPerDay: Math.round(avgDataPoints),
        avgMemoryUsage: Math.round(avgMemoryUsage * 100),
        avgCpuUsage: Math.round(avgCpuUsage * 100),
        avgResponseTime: Math.round(avgResponseTime),
        totalErrors,
        totalOptimizations,
        dataRetentionDays: this.config.retentionDays
      };
    }

    getAnalyticsReport() {
      return {
        isActive: this.state.isActive,
        isVisible: this.state.isVisible,
        lastUpdate: this.state.lastUpdate,
        totalDataPoints: Array.from(this.state.analyticsData.values()).reduce((sum, data) => sum + data.length, 0),
        activeAlerts: this.state.alerts.length,
        retentionDays: this.config.retentionDays,
        summary: this.generateSummary(),
        dashboardStats: this.getDashboardStats(),
        chartCount: this._charts.length
      };
    }

    execute() {
      if (this.config.enabled) {
        this.attachDashboardUI();
        this.startDataMonitoring();
      }
      console.log(`[${MODULE_NAME}] Execute called`);
    }

    destroy() {
      try {
        this.stopDataMonitoring();
        this.removeDashboardUI();
        console.log(`[${MODULE_NAME}] Cleanup complete`);
      } catch (err) {
        console.error(`[${MODULE_NAME}] Cleanup error:`, err);
      }
    }

    removeDashboardUI() {
      const container = this.getDashboardContainer();
      if (container) {
        container.remove();
      }
    }

    getChartIcon(type) {
      const icons = { line: '📈', bar: '📊', pie: '🥧', donut: '🍩' };
      return icons[type] || '📈';
    }
  }

  const instance = new AIAnalyticsDashboardModule();
  window[MODULE_INSTANCE_NAME] = instance;
  if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
    window.ChatGPTModules.register(instance);
  } else if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
    window.ModuleRegistry.register(instance);
  } else {
    window[PRIMARY_API_NAME] = instance.api;
    mergeApiSurface(SHARED_API_NAME, instance.api);
    try {
      instance.init();
      instance.execute();
    } catch (err) {
      console.error(`[${MODULE_NAME}] fallback error`, err);
    }
  }
})();
