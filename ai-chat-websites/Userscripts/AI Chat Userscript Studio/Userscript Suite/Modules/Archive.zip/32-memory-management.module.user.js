// ==UserScript==
// @name         32. Memory Management .M
// @namespace    http://tampermonkey.net/
// @version      2026.04.28.0
// @description  Memory management tools for AI chat with memory pool and garbage collection tuning
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://perplexity.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(function() {
  'use strict';

  class AIRMDMemoryManagementModule {
    constructor() {
      this.name = 'AIRMDMemoryManagement';
      this.version = '2026.03.28.1';
      this.dependencies = [];
      this.critical = false;
      this.config = {};
      this._trackedDisposables = new Set();
      this._pools = new Set();
      this.api = {
        tuneGarbageCollection: () => this.tuneGarbageCollection(),
        createMemoryPool: (factory, reset) => this.createMemoryPool(factory, reset),
        trackDisposable: (value) => this.trackDisposable(value),
        releaseTracked: () => this.releaseTracked(),
        estimateObjectSize: (value) => this.estimateObjectSize(value),
        init: () => this.initApi()
      };
    }

    init() {
      if (window.ConfigManager && typeof window.ConfigManager.getConfig === 'function') {
        this.config = {
          ...this.config,
          ...window.ConfigManager.getConfig('airmdmemorymanagement')
        };
      }

      window.AIRMDMemoryManagement = this.api;
      return this.api;
    }

    execute() {}

    onConfigUpdate(settings) {
      Object.assign(this.config, settings);
    }

    tuneGarbageCollection() {
      if (typeof window.gc !== 'function') {
        return false;
      }

      window.gc();
      return true;
    }

    createMemoryPool(factory = () => ({}), reset = null) {
      const pool = [];
      const entry = {
        allocate() {
          return pool.length > 0 ? pool.pop() : factory();
        },
        deallocate(item) {
          if (item == null) {
            return;
          }

          if (typeof reset === 'function') {
            reset(item);
          }

          pool.push(item);
        },
        size() {
          return pool.length;
        },
        clear() {
          pool.length = 0;
        }
      };

      this._pools.add(entry);
      return entry;
    }

    trackDisposable(value) {
      if (value != null) {
        this._trackedDisposables.add(value);
      }

      return value;
    }

    releaseTracked() {
      let released = 0;

      this._trackedDisposables.forEach((value) => {
        try {
          if (typeof value.dispose === 'function') {
            value.dispose();
          } else if (typeof value.destroy === 'function') {
            value.destroy();
          } else if (typeof value.abort === 'function') {
            value.abort();
          } else if (typeof value.disconnect === 'function') {
            value.disconnect();
          }
          released += 1;
        } catch (error) {
          console.warn('[AIRMDMemoryManagement] Failed to release tracked value:', error);
        }
      });

      this._trackedDisposables.clear();
      return released;
    }

    estimateObjectSize(value) {
      try {
        return JSON.stringify(value).length;
      } catch (error) {
        return 0;
      }
    }

    initApi() {
      return {
        trackedDisposables: this._trackedDisposables.size,
        pools: this._pools.size
      };
    }

    destroy() {
      this.releaseTracked();
      this._pools.forEach((pool) => pool.clear());
      this._pools.clear();
    }
  }

  const instance = new AIRMDMemoryManagementModule();
  window.AIRMDMemoryManagementModule = instance;

  // ✅ Legacy RMD Compatibility - Integrated
  const LEGACY_METHOD_ALIASES = {
    airmdInitMemoryManagement: "init",
    airmdTuneGarbageCollection: "tuneGarbageCollection",
    airmdCreateMemoryPool: "createMemoryPool",
    airmdTrackDisposable: "trackDisposable",
    airmdReleaseTracked: "releaseTracked",
    airmdEstimateObjectSize: "estimateObjectSize"
  };

  // Register legacy method aliases for backwards compatibility
  Object.entries(LEGACY_METHOD_ALIASES).forEach(([alias, methodName]) => {
    if (!window[alias] && typeof instance.api[methodName] === "function") {
      window[alias] = (...args) => instance.api[methodName](...args);
    }
  });

  if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
    window.ModuleRegistry.register(instance);

    // Also register legacy module name for compatibility
    try {
      const LegacyModule = class {
        constructor() {
          this.name = "21-rmd-memory-management";
          this.version = "2026.04.11.1";
          this.dependencies = [];
          this.critical = false;
        }
        init() {
          instance.init();
          return true;
        }
      };
      window.ModuleRegistry.register(new LegacyModule());
    } catch(e) {}
  } else if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
    window.ChatGPTModules.register(instance);
  } else {
    instance.init();
    instance.execute();
  }
})();
