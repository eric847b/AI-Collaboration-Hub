// desktop-modules.module.js
// Registers your desktop apps as sovereign modules

SovereignEngine.register("vscode", {
  onDelta(delta) {
    if (delta.source !== "vscode") return;
    return { vscodeHandled: true, delta };
  },
  onPerfect(_stableState) {
    // VS Code stabilization is observed passively.
  }
});

SovereignEngine.register("explorer", {
  onDelta(delta) {
    if (delta.source !== "explorer") return;
    return { explorerIndexed: true, delta };
  },
  onPerfect(_stableState) {
    // Explorer state updates are acknowledged without side effects.
  }
});

SovereignEngine.register("substrate", {
  onDelta(delta) {
    return { substrateObserved: delta.type };
  },
  onPerfect(_stableState) {
    // Substrate holds the state silently.
  }
});
