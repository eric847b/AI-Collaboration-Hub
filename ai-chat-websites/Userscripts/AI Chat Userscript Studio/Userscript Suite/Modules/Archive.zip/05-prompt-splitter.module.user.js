// ==UserScript==
// @name         5. Prompt Splitter
// @version      2026.03.14.1
// @description  ChatGPT - Prompt Splitting
// @author       AI RMD
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://poe.com/*
// @match        https://perplexity.ai/*
// @match        https://www.perplexity.ai/*
// @match        https://pi.ai/*
// @match        https://you.com/*
// @match        https://gemini.google.com/*
// @match        https://aistudio.google.com/*
// @match        https://copilot.microsoft.com/*
// @match        https://chat.mistral.ai/*
// @grant        GM_addStyle
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_notification
// @grant        GM_xmlhttpRequest
// @grant        GM_registerMenuCommand
// @grant        GM_unregisterMenuCommand
// @grant        GM_info
// @grant        GM_setClipboard
// @grant        GM_openInTab
// @grant        GM_getResourceText
// @grant        GM_getResourceURL
// @grant        GM_addValueChangeListener
// @grant        GM_removeValueChangeListener
// @require      https://cdn.jsdelivr.net/npm/@kudoai/chatgpt.js@latest/dist/chatgpt.min.js
// ==/UserScript==
(function() {
    'use strict';

    const chat = (window.ChatGPTUtils && typeof window.ChatGPTUtils.getChatAdapter === 'function')
        ? window.ChatGPTUtils.getChatAdapter()
        : (window.chatgpt || null);

    const safeChat = {
        sendMessage: (...args) => chat && typeof chat.sendMessage === 'function'
            ? chat.sendMessage(...args)
            : Promise.reject(new Error('sendMessage not supported on this site'))
    };

    // Enhanced Configuration with Smart Defaults
    const config = {
        // Core Settings
        maxCharsPerPart: 15000,
        minCharsPerPart: 1000,
        delayBetweenMessages: 1200,
        maxRetries: 3,
        
        // Advanced Features
        preserveCodeBlocks: true,
        smartSplitting: true,
        useProgressBar: true,
        showStats: true,
        
        // File Handling
        maxFileSizeMB: 50,
        allowedFileTypes: [
            '.txt', '.md', '.json', '.js', '.py', '.html', 
            '.css', '.sql', '.xml', '.yaml', '.sh'
        ],
        
        // UI/UX
        theme: {
            light: {
                background: '#ffffff',
                text: '#2c3e50',
                accent: '#3498db'
            },
            dark: {
                background: '#1a1a1a',
                text: '#ecf0f1',
                accent: '#3498db'
            }
        },
        
        // Performance
        chunkOverlap: 50,
        maxConcurrentRequests: 2,
        timeoutMs: 30000
    };

    // Smart Text Processing Engine
    class TextProcessor {
        static splitText(text) {
            if (!text?.trim()) return [];
            
            // Preserve code blocks
            const codeBlocks = new Map();
            let processedText = text.replace(/```[\s\S]*?```/g, (match, index) => {
                const placeholder = `__CODE_BLOCK_${index}__`;
                codeBlocks.set(placeholder, match);
                return placeholder;
            });

            // Smart splitting considering sentence boundaries
            const chunks = [];
            let currentChunk = '';
            const sentences = processedText.match(/[^.!?]+[.!?]+|\s*[^.!?\s]+(?:[.!?]|\s*$)|[^\n]+/g) || [];

            for (const sentence of sentences) {
                if ((currentChunk + sentence).length <= config.maxCharsPerPart) {
                    currentChunk += sentence;
                } else {
                    if (currentChunk) chunks.push(currentChunk.trim());
                    currentChunk = sentence;
                }
            }
            if (currentChunk) chunks.push(currentChunk.trim());

            // Restore code blocks
            return chunks.map(chunk => {
                let restoredChunk = chunk;
                codeBlocks.forEach((code, placeholder) => {
                    restoredChunk = restoredChunk.replace(placeholder, code);
                });
                return restoredChunk;
            });
        }
    }

    // Enhanced UI Manager
    class UIManager {
        constructor() {
            this.container = null;
            this.progressBar = null;
            this.stats = null;
            this.initializeUI();
        }

        initializeUI() {
            this.createContainer();
            this.createFileUploader();
            this.createProgressBar();
            this.createStats();
            this.registerCommands();
        }

        createContainer() {
            const styles = `
                .prompt-splitter-container {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    z-index: 9999;
                    background: ${this.isDarkMode() ? config.theme.dark.background : config.theme.light.background};
                    color: ${this.isDarkMode() ? config.theme.dark.text : config.theme.light.text};
                    padding: 15px;
                    border-radius: 12px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                    transition: all 0.3s ease;
                }
            `;
            GM_addStyle(styles);
            
            this.container = document.createElement('div');
            this.container.className = 'prompt-splitter-container';
            document.body.appendChild(this.container);
        }

        isDarkMode() {
            return window.matchMedia('(prefers-color-scheme: dark)').matches;
        }

        // Additional UI methods will be implemented here
    }

    // Message Handler
    class MessageHandler {
        static async sendMessages(chunks) {
            const results = [];
            let failCount = 0;

            for (let i = 0; i < chunks.length; i++) {
                try {
                    const result = await this.sendWithRetry(chunks[i], i + 1, chunks.length);
                    results.push(result);
                    failCount = 0;
                } catch (error) {
                    failCount++;
                    if (failCount >= config.maxRetries) {
                        throw new Error(`Failed to send messages after ${config.maxRetries} attempts`);
                    }
                    await this.delay(config.delayBetweenMessages * failCount);
                    i--; // Retry the same chunk
                }
            }
            return results;
        }

        static async sendWithRetry(message, current, total) {
            const formattedMessage = `[Part ${current}/${total}]\n\n${message}`;
            return safeChat.sendMessage(formattedMessage);
        }

        static delay(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
    }

    // Initialize the application
    const initialize = () => {
        const ui = new UIManager();
        
        // Register main command
        GM_registerMenuCommand('Split and Send Prompt', async () => {
            const text = prompt('Enter your prompt to split and send:');
            if (!text) return;
            
            const chunks = TextProcessor.splitText(text);
            await MessageHandler.sendMessages(chunks);
        });
    };

    // Start the application
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
})();
