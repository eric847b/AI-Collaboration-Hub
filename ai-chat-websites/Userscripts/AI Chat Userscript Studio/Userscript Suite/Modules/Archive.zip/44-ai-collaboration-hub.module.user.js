// ==UserScript==
// @name         44. AI Collaboration Hub .M
// @version      15.2
// @description  A central hub to collaborate with multiple AI services
// @author       Eric
// @license      MIT
// @match        *://chatgpt.com/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @grant        GM_xmlhttpRequest
// @connect      openai.com
// @connect      api.anthropic.com
// @connect      generativelanguage.googleapis.com
// @connect      www.google.com
// @connect      duckduckgo.com
// ==/UserScript==

(function() {
    'use strict';

    let hubInitialized = false;

    class AICollaborationHubModule {
        constructor() {
            this.name = 'AICollaborationHub';
            this.version = '15.2';
            this.dependencies = [];
            this.critical = false;
        }

        init() {
            return initializeCollaborationHub();
        }

        destroy() {
            return true;
        }
    }

    async function initializeCollaborationHub() {
        if (hubInitialized) {
            return true;
        }

        hubInitialized = true;
    console.log("🚀 AI Collaboration Hub v15.2 Initialized with Collaborative AI and Customizable Prompts!"); // Version bump

    const STORAGE_PREFIX = "aichub_v15_"; // Consistent storage prefix

    const API_KEYS = {
        openai: GM_getValue(STORAGE_PREFIX + "openai_key", ""),
        anthropic: GM_getValue(STORAGE_PREFIX + "anthropic_key", ""),
        google: GM_getValue(STORAGE_PREFIX + "google_key", "")
    };

    const SETTINGS = {
        autonomousAI: GM_getValue(STORAGE_PREFIX + "autonomous_ai", true),
        deepMemory: GM_getValue(STORAGE_PREFIX + "deep_memory", true),
        memoryContextLength: parseInt(GM_getValue(STORAGE_PREFIX + "memory_context_length", "3")),
        selfOptimizingAI: GM_getValue(STORAGE_PREFIX + "self_optimizing_ai", false),
        smartTaskExecution: GM_getValue(STORAGE_PREFIX + "smart_task_execution", false),
        enableOpenLinks: GM_getValue(STORAGE_PREFIX + "enable_open_links", true),
        enableSearchQueries: GM_getValue(STORAGE_PREFIX + "enable_search_queries", true),
        customSearchEngine: GM_getValue(STORAGE_PREFIX + "custom_search_engine", "https://www.google.com/search?q=%s"),
        enableSummarize: GM_getValue(STORAGE_PREFIX + "enable_summarize", true),
        enableCodeActions: GM_getValue(STORAGE_PREFIX + "enable_code_actions", true),
        enableTranslate: GM_getValue(STORAGE_PREFIX + "enable_translate", true),
        defaultTranslationLanguage: GM_getValue(STORAGE_PREFIX + "default_translation_language", ""),
        enableContinueDiscussion: GM_getValue(STORAGE_PREFIX + "enable_continue_discussion", true),
        enableSaveResponse: GM_getValue(STORAGE_PREFIX + "enable_save_response", true),
        customPromptTemplate: GM_getValue(STORAGE_PREFIX + "custom_prompt_template", ""),
        aiResponseTone: GM_getValue(STORAGE_PREFIX + "ai_response_tone", "default"),
        defaultAIService: GM_getValue(STORAGE_PREFIX + "default_ai_service", "openai"),
        customAggregationPrompt: GM_getValue(STORAGE_PREFIX + "custom_aggregation_prompt", "") // New setting
    };

    const ROLES = {
        openai: GM_getValue(STORAGE_PREFIX + "openai_role", "strategic planner"),
        anthropic: GM_getValue(STORAGE_PREFIX + "anthropic_role", "research analyst"),
        google: GM_getValue(STORAGE_PREFIX + "google_role", "creative thinker")
    };

    let aiMemory = JSON.parse(GM_getValue(STORAGE_PREFIX + "ai_memory", "[]"));
    let savedResponses = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_responses", "[]"));
    let savedConversations = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}"));
    let savedInteractions = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_interactions", "{}"));
    let promptTemplates = JSON.parse(GM_getValue(STORAGE_PREFIX + "prompt_templates", "{}")); // Load prompt templates
    let savedPrompts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_prompts", "{}")); // Load saved prompts
    let conversationHistory = []; // To store the current conversation

    const AI_SERVICES = ["openai", "anthropic", "google"];
    const PREDEFINED_ROLES = {
        default: "Default",
        strategic_planner: "Strategic Planner",
        research_analyst: "Research Analyst",
        creative_thinker: "Creative Thinker",
        technical_writer: "Technical Writer",
        code_generator: "Code Generator",
        summarizer: "Summarizer",
        translator: "Translator",
        custom: "Custom"
    };

    const PREDEFINED_TONES = {
        default: "Default",
        formal: "Formal",
        informal: "Informal",
        technical: "Technical",
        creative: "Creative",
        concise: "Concise",
        detailed: "Detailed",
        humorous: "Humorous"
    };

    let settingsPanelVisible = false;

    await loadSettings();
    injectUI();
    registerContextMenuCommands();

    async function loadSettings() {
        for (const key in API_KEYS) { API_KEYS[key] = GM_getValue(STORAGE_PREFIX + key + "_key", ""); }
        for (const key in SETTINGS) { SETTINGS[key] = GM_getValue(STORAGE_PREFIX + key, SETTINGS[key]); }
        for (const key in ROLES) { ROLES[key] = GM_getValue(STORAGE_PREFIX + key + "_role", ROLES[key]); }
        aiMemory = JSON.parse(GM_getValue(STORAGE_PREFIX + "ai_memory", "[]"));
        savedResponses = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_responses", "[]"));
        savedConversations = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}"));
        savedInteractions = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_interactions", "{}"));
        promptTemplates = JSON.parse(GM_getValue(STORAGE_PREFIX + "prompt_templates", "{}")); // Load
        savedPrompts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_prompts", "{}")); // Load
        SETTINGS.customAggregationPrompt = GM_getValue(STORAGE_PREFIX + "custom_aggregation_prompt", ""); // Load new setting
    }

    function saveSettings() {
        for (const key in API_KEYS) { GM_setValue(STORAGE_PREFIX + key + "_key", API_KEYS[key]); }
        for (const key in SETTINGS) { GM_setValue(STORAGE_PREFIX + key, SETTINGS[key]); }
        for (const key in ROLES) { GM_setValue(STORAGE_PREFIX + key + "_role", ROLES[key]); }
        GM_setValue(STORAGE_PREFIX + "ai_memory", JSON.stringify(aiMemory));
        GM_setValue(STORAGE_PREFIX + "saved_responses", JSON.stringify(savedResponses));
        GM_setValue(STORAGE_PREFIX + "saved_conversations", JSON.stringify(savedConversations));
        GM_setValue(STORAGE_PREFIX + "saved_interactions", JSON.stringify(savedInteractions));
        GM_setValue(STORAGE_PREFIX + "prompt_templates", JSON.stringify(promptTemplates)); // Save
        GM_setValue(STORAGE_PREFIX + "saved_prompts", JSON.stringify(savedPrompts)); // Save
        GM_setValue(STORAGE_PREFIX + "custom_aggregation_prompt", SETTINGS.customAggregationPrompt); // Save new setting
    }

    function saveAIResponse(response) { /* Placeholder: Implement logic to save individual responses */ }
    async function fetchAIResponse(prompt, service = "openai", customRole = null) { /* Placeholder: Implement API calls to different AI services */
        console.log(`Workspaceing response from ${service} for prompt: ${prompt} (Role: ${customRole || ROLES[service]})`);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
        const responseText = `Simulated response from ${service.toUpperCase()} for: "${prompt}"`;
        return { service: service, result: responseText };
    }
    async function fetchAISummary(text) { /* Placeholder: Implement summarization functionality */ console.log("Summarizing:", text); return "Simulated summary."; }
    async function fetchAITranslation(text, targetLanguage) { /* Placeholder: Implement translation functionality */ console.log(`Translating "${text}" to ${targetLanguage}`); return `Simulated translation to ${targetLanguage}.`; }
    function displaySavedResponses() { /* Placeholder: Implement UI to display saved responses */ }
    function exportConversationHistory() { /* Placeholder: Implement logic to export the current conversation history */ }
    function createSettingsPanel() {
        const settingsPanel = document.createElement("div");
        settingsPanel.id = "ai-hub-settings-panel";
        settingsPanel.style.cssText = `position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #f8f9fa; color: #212529; padding: 20px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.15); z-index: 10001; display: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 14px; width: 450px; max-height: 80vh; overflow-y: auto;`;

        const title = document.createElement("h2");
        title.innerText = "AI Collaboration Hub Settings";
        title.style.marginBottom = "20px";
        settingsPanel.appendChild(title);

        // --- API Keys Section ---
        const apiKeysSection = document.createElement("div");
        apiKeysSection.style.marginBottom = "20px";
        const apiKeysHeader = document.createElement("h3");
        apiKeysHeader.innerText = "🔑 API Keys";
        apiKeysHeader.style.marginBottom = "10px";
        apiKeysSection.appendChild(apiKeysHeader);

        AI_SERVICES.forEach(service => {
            const label = document.createElement("label");
            label.innerText = `${service.toUpperCase()} API Key:`;
            label.style.display = "block";
            label.style.marginBottom = "5px";
            const input = document.createElement("input");
            input.type = "text";
            input.value = API_KEYS[service];
            input.style.width = "100%";
            input.style.padding = "8px";
            input.style.marginBottom = "10px";
            input.style.borderRadius = "4px";
            input.style.border = "1px solid #ced4da";
            input.onchange = (e) => API_KEYS[service] = e.target.value;
            apiKeysSection.appendChild(label);
            apiKeysSection.appendChild(input);
        });
        settingsPanel.appendChild(apiKeysSection);

        // --- AI Roles Section ---
        const aiRolesSection = document.createElement("div");
        aiRolesSection.style.marginBottom = "20px";
        const aiRolesHeader = document.createElement("h3");
        aiRolesHeader.innerText = "🎭 AI Roles";
        aiRolesHeader.style.marginBottom = "10px";
        aiRolesSection.appendChild(aiRolesHeader);

        AI_SERVICES.forEach(service => {
            const label = document.createElement("label");
            label.innerText = `${service.toUpperCase()} Role:`;
            label.style.display = "block";
            label.style.marginBottom = "5px";
            const select = document.createElement("select");
            select.style.width = "100%";
            select.style.padding = "8px";
            select.style.marginBottom = "10px";
            select.style.borderRadius = "4px";
            select.style.border = "1px solid #ced4da";
            for (const roleKey in PREDEFINED_ROLES) {
                const option = document.createElement("option");
                option.value = roleKey;
                option.innerText = PREDEFINED_ROLES[roleKey];
                option.selected = ROLES[service] === roleKey;
                select.appendChild(option);
            }
            select.onchange = (e) => {
                if (e.target.value === 'custom') {
                    const customRole = prompt(`Enter custom role for ${service.toUpperCase()}:`, ROLES[service] === 'custom' ? GM_getValue(STORAGE_PREFIX + service + "_custom_role", "") : "");
                    if (customRole !== null) {
                        ROLES[service] = 'custom';
                        GM_setValue(STORAGE_PREFIX + service + "_custom_role", customRole);
                        loadSettings(); // Reload settings to update dropdown if needed
                        createSettingsPanel(); // Re-render the settings panel
                    } else {
                        select.value = ROLES[service]; // Revert if no custom role provided
                    }
                } else {
                    ROLES[service] = e.target.value;
                }
            };
            aiRolesSection.appendChild(label);
            aiRolesSection.appendChild(select);
            if (ROLES[service] === 'custom') {
                const customRoleLabel = document.createElement("label");
                customRoleLabel.innerText = `Custom Role for ${service.toUpperCase()}:`;
                customRoleLabel.style.display = "block";
                customRoleLabel.style.marginBottom = "5px";
                const customRoleText = document.createElement("div");
                customRoleText.innerText = GM_getValue(STORAGE_PREFIX + service + "_custom_role", "");
                customRoleText.style.padding = "8px";
                customRoleText.style.marginBottom = "10px";
                customRoleText.style.border = "1px solid #eee";
                customRoleText.style.borderRadius = "4px";
                aiRolesSection.appendChild(customRoleLabel);
                aiRolesSection.appendChild(customRoleText);
            }
        });
        settingsPanel.appendChild(aiRolesSection);

        // --- Core Functionality Section ---
        const coreFunctionalitySection = document.createElement("div");
        coreFunctionalitySection.style.marginBottom = "20px";
        const coreFunctionalityHeader = document.createElement("h3");
        coreFunctionalityHeader.innerText = "⚙️ Core Functionality";
        coreFunctionalityHeader.style.marginBottom = "10px";
        coreFunctionalitySection.appendChild(coreFunctionalityHeader);

        const defaultServiceLabel = document.createElement("label");
        defaultServiceLabel.innerText = "Default AI Service:";
        defaultServiceLabel.style.display = "block";
        defaultServiceLabel.style.marginBottom = "5px";
        const defaultServiceSelect = document.createElement("select");
        defaultServiceSelect.style.width = "100%";
        defaultServiceSelect.style.padding = "8px";
        defaultServiceSelect.style.marginBottom = "10px";
        defaultServiceSelect.style.borderRadius = "4px";
        defaultServiceSelect.style.border = "1px solid #ced4da";
        AI_SERVICES.forEach(service => {
            const option = document.createElement("option");
            option.value = service;
            option.innerText = service.toUpperCase();
            option.selected = SETTINGS.defaultAIService === service;
            defaultServiceSelect.appendChild(option);
        });
        defaultServiceSelect.onchange = (e) => SETTINGS.defaultAIService = e.target.value;
        coreFunctionalitySection.appendChild(defaultServiceLabel);
        coreFunctionalitySection.appendChild(defaultServiceSelect);

        const responseToneLabel = document.createElement("label");
        responseToneLabel.innerText = "AI Response Tone:";
        responseToneLabel.style.display = "block";
        responseToneLabel.style.marginBottom = "5px";
        const responseToneSelect = document.createElement("select");
        responseToneSelect.style.width = "100%";
        responseToneSelect.style.padding = "8px";
        responseToneSelect.style.marginBottom = "10px";
        responseToneSelect.style.borderRadius = "4px";
        responseToneSelect.style.border = "1px solid #ced4da";
        for (const toneKey in PREDEFINED_TONES) {
            const option = document.createElement("option");
            option.value = toneKey;
            option.innerText = PREDEFINED_TONES[toneKey];
            option.selected = SETTINGS.aiResponseTone === toneKey;
            responseToneSelect.appendChild(option);
        }
        responseToneSelect.onchange = (e) => SETTINGS.aiResponseTone = e.target.value;
        coreFunctionalitySection.appendChild(responseToneLabel);
        coreFunctionalitySection.appendChild(responseToneSelect);

        // Add checkboxes for other core functionalities
        const coreFeatures = [
            { id: "enableSummarize", label: "Enable Summarize Action" },
            { id: "enableCodeActions", label: "Enable Code Actions" },
            { id: "enableTranslate", label: "Enable Translate Action" },
            { id: "enableContinueDiscussion", label: "Enable Continue Discussion" },
            { id: "enableSaveResponse", label: "Enable Save Response" },
            { id: "enableOpenLinks", label: "Enable Open Links from AI Responses" },
            { id: "enableSearchQueries", label: "Enable Search Queries in AI Responses" }
        ];
        coreFeatures.forEach(feature => {
            const checkboxDiv = document.createElement("div");
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.id = feature.id;
            checkbox.checked = SETTINGS[feature.id];
            checkbox.onchange = (e) => SETTINGS[feature.id] = e.target.checked;
            const label = document.createElement("label");
            label.innerText = feature.label;
            label.htmlFor = feature.id;
            label.style.marginLeft = "5px";
            checkboxDiv.appendChild(checkbox);
            checkboxDiv.appendChild(label);
            coreFunctionalitySection.appendChild(checkboxDiv);
        });

        settingsPanel.appendChild(coreFunctionalitySection);

        // --- Smart Actions Section ---
        const smartActionsSection = document.createElement("div");
        smartActionsSection.style.marginBottom = "20px";
        const smartActionsHeader = document.createElement("h3");
        smartActionsHeader.innerText = "💡 Smart Actions";
        smartActionsHeader.style.marginBottom = "10px";
        smartActionsSection.appendChild(smartActionsHeader);

        const autonomousAICheckbox = document.createElement("div");
        const autonomousAIInput = document.createElement("input");
        autonomousAIInput.type = "checkbox";
        autonomousAIInput.id = "autonomousAI";
        autonomousAIInput.checked = SETTINGS.autonomousAI;
        autonomousAIInput.onchange = (e) => SETTINGS.autonomousAI = e.target.checked;
        const autonomousAILabel = document.createElement("label");
        autonomousAILabel.innerText = "Enable Autonomous AI (Experimental)";
        autonomousAILabel.htmlFor = "autonomousAI";
        autonomousAILabel.style.marginLeft = "5px";
        autonomousAICheckbox.appendChild(autonomousAIInput);
        autonomousAICheckbox.appendChild(autonomousAILabel);
        smartActionsSection.appendChild(autonomousAICheckbox);

        const deepMemoryCheckbox = document.createElement("div");
        const deepMemoryInput = document.createElement("input");
        deepMemoryInput.type = "checkbox";
        deepMemoryInput.id = "deepMemory";
        deepMemoryInput.checked = SETTINGS.deepMemory;
        deepMemoryInput.onchange = (e) => SETTINGS.deepMemory = e.target.checked;
        const deepMemoryLabel = document.createElement("label");
        deepMemoryLabel.innerText = "Enable Deep Memory";
        deepMemoryLabel.htmlFor = "deepMemory";
        deepMemoryLabel.style.marginLeft = "5px";
        deepMemoryCheckbox.appendChild(deepMemoryInput);
        deepMemoryCheckbox.appendChild(deepMemoryLabel);
        smartActionsSection.appendChild(deepMemoryCheckbox);

        const memoryContextLabel = document.createElement("label");
        memoryContextLabel.innerText = "Memory Context Length:";
        memoryContextLabel.style.display = "block";
        memoryContextLabel.style.marginLeft = "20px";
        memoryContextLabel.style.marginBottom = "5px";
        const memoryContextInput = document.createElement("input");
        memoryContextInput.type = "number";
        memoryContextInput.id = "memoryContextLength";
        memoryContextInput.value = SETTINGS.memoryContextLength;
        memoryContextInput.style.width = "60px";
        memoryContextInput.onchange = (e) => SETTINGS.memoryContextLength = parseInt(e.target.value) || 3;
        deepMemoryCheckbox.appendChild(memoryContextLabel);
        deepMemoryCheckbox.appendChild(memoryContextInput);

        const selfOptimizingAICheckbox = document.createElement("div");
        const selfOptimizingAIInput = document.createElement("input");
        selfOptimizingAIInput.type = "checkbox";
        selfOptimizingAIInput.id = "selfOptimizingAI";
        selfOptimizingAIInput.checked = SETTINGS.selfOptimizingAI;
        selfOptimizingAIInput.onchange = (e) => SETTINGS.selfOptimizingAI = e.target.checked;
        const selfOptimizingAILabel = document.createElement("label");
        selfOptimizingAILabel.innerText = "Enable Self-Optimizing AI (Experimental)";
        selfOptimizingAILabel.htmlFor = "selfOptimizingAI";
        selfOptimizingAILabel.style.marginLeft = "5px";
        selfOptimizingAICheckbox.appendChild(selfOptimizingAIInput);
        selfOptimizingAICheckbox.appendChild(selfOptimizingAILabel);
        smartActionsSection.appendChild(selfOptimizingAICheckbox);

        const smartTaskExecutionCheckbox = document.createElement("div");
        const smartTaskExecutionInput = document.createElement("input");
        smartTaskExecutionInput.type = "checkbox";
        smartTaskExecutionInput.id = "smartTaskExecution";
        smartTaskExecutionInput.checked = SETTINGS.smartTaskExecution;
        smartTaskExecutionInput.onchange = (e) => SETTINGS.smartTaskExecution = e.target.checked;
        const smartTaskExecutionLabel = document.createElement("label");
        smartTaskExecutionLabel.innerText = "Enable Smart Task Execution (Experimental)";
        smartTaskExecutionLabel.htmlFor = "smartTaskExecution";
        smartTaskExecutionLabel.style.marginLeft = "5px";
        smartTaskExecutionCheckbox.appendChild(smartTaskExecutionInput);
        smartTaskExecutionCheckbox.appendChild(smartTaskExecutionLabel);
        smartActionsSection.appendChild(smartTaskExecutionCheckbox);

        // --- Collaboration Settings ---
        const collaborationSettingsSection = document.createElement("div");
        collaborationSettingsSection.style.marginBottom = "20px";
        const collaborationSettingsHeader = document.createElement("h3");
        collaborationSettingsHeader.innerText = "🤝 Collaboration Settings";
        collaborationSettingsHeader.style.marginBottom = "10px";
        collaborationSettingsSection.appendChild(collaborationSettingsHeader);

        const customAggregationPromptLabel = document.createElement("label");
        customAggregationPromptLabel.innerText = "Custom Aggregation Prompt (optional):";
        customAggregationPromptLabel.style.display = "block";
        customAggregationPromptLabel.style.marginBottom = "5px";
        const customAggregationPromptTextarea = document.createElement("textarea");
        customAggregationPromptTextarea.id = "custom-aggregation-prompt";
        customAggregationPromptTextarea.value = SETTINGS.customAggregationPrompt;
        customAggregationPromptTextarea.style.width = "100%";
        customAggregationPromptTextarea.style.minHeight = "80px";
        customAggregationPromptTextarea.style.padding = "8px";
        customAggregationPromptTextarea.style.marginBottom = "10px";
        customAggregationPromptTextarea.onchange = (e) => SETTINGS.customAggregationPrompt = e.target.value;
        collaborationSettingsSection.appendChild(customAggregationPromptLabel);
        collaborationSettingsSection.appendChild(customAggregationPromptTextarea);

        smartActionsSection.appendChild(collaborationSettingsSection); // Append to Smart Actions for now, can be moved

        settingsPanel.appendChild(smartActionsSection);

        // --- UI Options Section ---
        const uiOptionsSection = document.createElement("div");
        uiOptionsSection.style.marginBottom = "20px";
        const uiOptionsHeader = document.createElement("h3");
        uiOptionsHeader.innerText = "🎨 UI Options";
        uiOptionsHeader.style.marginBottom = "10px";
        uiOptionsSection.appendChild(uiOptionsHeader);

        // Add any UI related settings here in the future

        settingsPanel.appendChild(uiOptionsSection);

        // --- Data Management Section ---
        const dataManagementSection = document.createElement("div");
        dataManagementSection.style.marginBottom = "20px";
        const dataManagementHeader = document.createElement("h3");
        dataManagementHeader.innerText = "💾 Data Management";
        dataManagementHeader.style.marginBottom = "10px";
        dataManagementSection.appendChild(dataManagementHeader);

        const exportDataButton = document.createElement("button");
        exportDataButton.innerText = "Export Saved Data";
        applyButtonStyle(exportDataButton, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#28a745', color: 'white', marginBottom: '10px', display: 'block', width: '100%', borderRadius: '5px' });
        exportDataButton.onclick = exportSavedData;
        dataManagementSection.appendChild(exportDataButton);

        const importDataLabel = document.createElement("label");
        importDataLabel.innerText = "Import Saved Data:";
        importDataLabel.style.display = "block";
        importDataLabel.style.marginBottom = "5px";
        dataManagementSection.appendChild(importDataLabel);

        const importFileInput = document.createElement("input");
        importFileInput.type = "file";
        importFileInput.id = "import-data-file";
        importFileInput.accept = ".json";
        importFileInput.style.width = "100%";
        importFileInput.style.marginBottom = "10px";
        dataManagementSection.appendChild(importFileInput);

        const importDataButton = document.createElement("button");
        importDataButton.innerText = "Import Data";
        applyButtonStyle(importDataButton, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#007bff', color: 'white', width: '100%', borderRadius: '5px' });
        importDataButton.onclick = handleImportData;
        dataManagementSection.appendChild(importDataButton);

        settingsPanel.appendChild(dataManagementSection);

        // --- Prompt Templates Section ---
        const promptTemplatesSection = document.createElement("div");
        promptTemplatesSection.style.marginBottom = "20px";
        const promptTemplatesHeader = document.createElement("h3");
        promptTemplatesHeader.innerText = "📝 Prompt Templates";
        promptTemplatesHeader.style.marginBottom = "10px";
        promptTemplatesSection.appendChild(promptTemplatesHeader);

        const templateListDiv = document.createElement("div");
        templateListDiv.id = "prompt-templates-list";
        promptTemplatesSection.appendChild(templateListDiv);

        const addTemplateButton = document.createElement("button");
        addTemplateButton.innerText = "Add New Template";
        applyButtonStyle(addTemplateButton, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#17a2b8', color: 'white', marginBottom: '10px', display: 'block', width: '100%', borderRadius: '5px' });
        addTemplateButton.onclick = () => showEditTemplateModal();
        promptTemplatesSection.appendChild(addTemplateButton);

        settingsPanel.appendChild(promptTemplatesSection);

        const saveButton = document.createElement("button");
        saveButton.innerText = "Save Settings";
        applyButtonStyle(saveButton, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#28a745', color: 'white', borderRadius: '5px', marginRight: '10px' });
        saveButton.onclick = saveSettings;
        settingsPanel.appendChild(saveButton);

        const closeButton = document.createElement("button");
        closeButton.innerText = "Close Settings";
        applyButtonStyle(closeButton, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#6c757d', color: 'white', borderRadius: '5px' });
        closeButton.onclick = () => {
            document.getElementById("ai-hub-settings-panel").style.display = "none";
            settingsPanelVisible = false;
        };
        settingsPanel.appendChild(closeButton);

        document.body.appendChild(settingsPanel);

        loadPromptTemplatesUI(); // Load templates when settings panel is created
    }

    function checkAndMarkEditedPrompt(currentPrompt) { /* Placeholder: Implement logic to track if the prompt has been manually edited */ }

    function injectUI() {
        let aiHubDiv = document.getElementById("ai-collaboration-hub");
        if (!aiHubDiv) {
            aiHubDiv = document.createElement("div");
            aiHubDiv.id = "ai-collaboration-hub";
            aiHubDiv.style.cssText = `
                position: fixed; top: 20px; right: 20px;
                width: 350px; background: #f8f9fa; color: #212529;
                border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.15);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 14px; z-index: 10000;
            `;
            document.body.appendChild(aiHubDiv);

            const style = document.createElement('style');
            style.textContent = `
                #ai-collaboration-hub h4 {
                    margin-top: 0;
                    margin-bottom: 10px;
                    color: #333;
                }
                #saved-conversations-list button, #saved-interactions-list button,
                #prompt-templates-list button {
                    margin-right: 5px;
                    margin-bottom: 5px;
                    padding: 6px 10px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    background-color: #f9f9f9;
                    color: #333;
                    cursor: pointer;
                    font-size: 13px;
                }
                #saved-conversations-list button:hover, #saved-interactions-list button:hover,
                #prompt-templates-list button:hover {
                    background-color: #eee;
                }
                #saved-conversations-list .conversation-item, #saved-interactions-list .interaction-item,
                #prompt-templates-list .template-item, #saved-prompts-list .prompt-item {
                    display: flex;
                    align-items: center;
                    margin-bottom: 8px;
                    padding: 8px;
                    border-radius: 4px;
                    background-color: #fff;
                    border: 1px solid #eee;
                }
                #saved-conversations-list .conversation-item button:first-child,
                #saved-interactions-list .interaction-item button:first-child,
                #prompt-templates-list .template-item span, #saved-prompts-list .prompt-item button:first-child {
                    flex-grow: 1;
                }
                #saved-conversations-list .conversation-item button:not(:first-child),
                #saved-interactions-list .interaction-item button:not(:first-child),
                #prompt-templates-list .template-item button, #saved-prompts-list .prompt-item button:not(:first-child) {
                    margin-left: 5px;
                }
                #prompt-template-select {
                    width: calc(100% - 16px);
                    padding: 8px;
                    margin-bottom: 10px;
                    border: 1px solid #ced4da;
                    border-radius: 4px;
                    box-sizing: border-box;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    font-size: 14px;
                }
                #ai-prompt-input {
                    width: calc(100% - 16px);
                    min-height: 100px;
                    margin-bottom: 10px;
                    padding: 8px;
                    border: 1px solid #ced4da;
                    border-radius: 4px;
                    box-sizing: border-box;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    font-size: 14px;
                }
                #ai-collaboration-hub button {
                    padding: 10px 15px;
                    font-size: 16px;
                    background-color: #007bff;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    width: 100%;
                    display: block;
                    margin-top: 10px;
                }
                #ai-collaboration-hub button:hover {
                    background-color: #0056b3;
                }
                #ai-collaboration-hub label {
                    display: block;
                    margin-bottom: 5px;
                    font-weight: bold;
                    color: #555;
                }
                #ai-collaboration-hub select {
                    width: calc(100% - 16px);
                    padding: 8px;
                    margin-bottom: 10px;
                    border: 1px solid #ced4da;
                    border-radius: 4px;
                    box-sizing: border-box;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    font-size: 14px;
                }
                #ai-collab-box {
                    padding: 15px;
                    margin-top: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    background-color: #fff;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    font-size: 14px;
                    white-space: pre-wrap;
                }
                #ai-collab-box > div {
                    margin-bottom: 15px;
                    padding: 10px;
                    border: 1px solid #eee;
                    border-radius: 4px;
                    background-color: #f9f9f9;
                    display: flex; /* For save interaction button */
                    flex-direction: column; /* Arrange content vertically */
                }
                #ai-collab-box > div > div { /* Container for response text */
                    margin-bottom: 10px; /* Space between text and button */
                }
                #ai-collab-box b {
                    font-weight: bold;
                    color: #333;
                    margin-right: 5px;
                }
                #ai-collab-box button {
                    padding: 5px 10px;
                    font-size: 12px;
                    background-color: #6c757d;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    margin-left: 5px;
                    align-self: flex-end; /* Push button to the right/bottom */
                }
                #ai-collab-box button:hover {
                    background-color: #5a6268;
                }
                #save-conversation-button {
                    background-color: #17a2b8;
                }
                #save-conversation-button:hover {
                    background-color: #138496;
                }
            `;
            aiHubDiv.appendChild(style);

            const header = document.createElement("div");
            header.style.cssText = `padding: 15px; background: #007bff; color: white; border-top-left-radius: 8px; border-top-right-radius: 8px; display: flex; justify-content: space-between; align-items: center;`;
            header.innerHTML = `<b>🤖 AI Collaboration Hub</b>`;
            aiHubDiv.appendChild(header);

            const settingsToggleButton = document.createElement("button");
            settingsToggleButton.innerHTML = "⚙️"; // Gear icon
            applyButtonStyle(settingsToggleButton, { padding: '5px 10px', fontSize: '16px', backgroundColor: 'transparent', color: 'white', border: 'none', cursor: 'pointer' });
            settingsToggleButton.onclick = () => {
                settingsPanelVisible = !settingsPanelVisible;
                const settingsPanel = document.getElementById("ai-hub-settings-panel");
                if (settingsPanel) {
                    settingsPanel.style.display = settingsPanelVisible ? "block" : "none";
                } else {
                    createSettingsPanel();
                    document.getElementById("ai-hub-settings-panel").style.display = "block";
                    settingsPanelVisible = true;
                }
            };
            header.appendChild(settingsToggleButton);

            const inputArea = document.createElement("div");
            inputArea.style.padding = "15px";
            aiHubDiv.appendChild(inputArea);

            const promptLabel = document.createElement("label");
            promptLabel.innerText = "Enter your prompt:";
            inputArea.appendChild(promptLabel);

            const promptInput = document.createElement("textarea");
            promptInput.id = "ai-prompt-input";
            inputArea.appendChild(promptInput);

            // --- Prompt Templates Dropdown ---
            const templateSelectLabel = document.createElement("label");
            templateSelectLabel.innerText = "Use a Template (optional):";
            inputArea.appendChild(templateSelectLabel);

            const templateSelect = document.createElement("select");
            templateSelect.id = "prompt-template-select";
            const defaultOption = document.createElement("option");
            defaultOption.value = "";
            defaultOption.innerText = "-- Select a Template --";
            templateSelect.appendChild(defaultOption);
            for (const name in promptTemplates) {
                const option = document.createElement("option");
                option.value = name;
                option.innerText = name;
                templateSelect.appendChild(option);
            }
            templateSelect.onchange = () => {
                const selectedTemplateName = templateSelect.value;
                if (selectedTemplateName) {
                    document.getElementById("ai-prompt-input").value = promptTemplates[selectedTemplateName];
                }
            };
            inputArea.appendChild(templateSelect);

            const serviceSelectLabel = document.createElement("label");
            serviceSelectLabel.innerText = "Choose AI Services to Compare:";
            inputArea.appendChild(serviceSelectLabel);

            const serviceSelectContainer = document.createElement("div");
            serviceSelectContainer.style.display = "flex";
            serviceSelectContainer.style.flexDirection = "column";
            inputArea.appendChild(serviceSelectContainer);

            const selectedServices = [];
            AI_SERVICES.forEach(service => {
                const checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.id = `service-${service}`;
                checkbox.value = service;
                if (SETTINGS.defaultAIService === service) {
                    checkbox.checked = true;
                    selectedServices.push(service);
                }
                checkbox.style.marginRight = "5px";

                const label = document.createElement("label");
                label.innerText = service.toUpperCase();
                label.htmlFor = `service-${service}`;
                label.style.marginBottom = "3px";
                label.style.display = "block";

                const serviceDiv = document.createElement("div");
                serviceDiv.style.display = "flex";
                serviceDiv.style.alignItems = "center";
                serviceDiv.appendChild(checkbox);
                serviceDiv.appendChild(label);
                serviceSelectContainer.appendChild(serviceDiv);
            });

            const collaborateButton = document.createElement("button");
            collaborateButton.innerText = "Compare with AI";
            inputArea.appendChild(collaborateButton);
            collaborateButton.onclick = async () => {
                let prompt = document.getElementById("ai-prompt-input").value;
                const selectedServices = Array.from(document.querySelectorAll('#ai-collaboration-hub input[type="checkbox"]:checked'))
                    .map(checkbox => checkbox.value);
                const defaultService = selectedServices[0] || SETTINGS.defaultAIService; // Use first selected or default for aggregation

                if (prompt.trim() && selectedServices.length > 0) {
                    const placeholders = prompt.match(/%[A-Z0-9_]+%/g);
                    if (placeholders) {
                        for (const placeholder of placeholders) {
                            const replacement = prompt(`Enter value for ${placeholder}:`);
                            if (replacement === null) {
                                return;
                            }
                            prompt = prompt.replace(placeholder, replacement);
                        }
                    }

                    const allResponses = [];
                    conversationHistory.push({ role: 'user', content: prompt }); // Add user prompt to history

                    // --- Smart Task: Research and Summarize (No change here for now) ---
                    if (prompt.toLowerCase().startsWith("research and summarize ")) {
                        const topic = prompt.substring("research and summarize ".length).trim();
                        if (topic) {
                            const searchUrl = SETTINGS.customSearchEngine.replace("%s", encodeURIComponent(topic));
                            const searchResults = `<p>Searching for: <a href="${searchUrl}" target="_blank">${topic}</a>. Please review the search results to provide context for the AI.</p>`;
                            displayCollaboration([{ service: 'search', result: searchResults, isSearchResult: true }]);

                            const summaryPrompt = `Based on the information you can access or have been provided (including the context from the search results I might review), summarize the key points about: ${topic}`;
                            const summaryResponse = await fetchAIResponse(summaryPrompt, defaultService);
                            if (summaryResponse) {
                                allResponses.push(summaryResponse);
                                aiMemory.push({ prompt: summaryPrompt, response: summaryResponse.result || summaryResponse.error, service: defaultService, isSubTask: true });
                                conversationHistory.push({ role: summaryResponse.service, content: summaryResponse.result || summaryResponse.error }); // Add AI response to history
                            }
                        } else {
                            alert("Please specify a topic to research and summarize.");
                        }
                    } else {
                        // --- Regular Collaboration ---
                        for (const service of selectedServices) {
                            const response = await fetchAIResponse(prompt, service, ROLES[service] === 'custom' ? GM_getValue(STORAGE_PREFIX + service + "_custom_role", "") : ROLES[service]);
                            if (response) {
                                allResponses.push(response);
                                aiMemory.push({ prompt: prompt, response: response.result || response.error, service: service });
                                conversationHistory.push({ role: service, content: response.result || response.error }); // Add AI response to history
                            }

                            // --- Generate Collaborative Result ---
                            if (selectedServices.length > 1) {
                                const collabBox = document.getElementById("ai-collab-box");
                                const loadingMessageDiv = document.createElement("div");
                                loadingMessageDiv.innerText = "Generating collaborative result...";
                                collabBox.appendChild(loadingMessageDiv);

                                let aggregationPromptText = SETTINGS.customAggregationPrompt;
                                if (!aggregationPromptText) {
                                    aggregationPromptText = `You are a collaborative AI. Your task is to synthesize the following responses from different AI models to the user's prompt: "${prompt}". Provide a single, comprehensive result that integrates the key insights and perspectives from all the responses. Here are the individual responses:\n\n%INDIVIDUAL_RESPONSES%`;
                                }
                                const individualResponsesFormatted = allResponses.map(res => `${res.service.toUpperCase()}: ${res.result}`).join('\n\n');
                                const finalAggregationPrompt = aggregationPromptText.replace('%INDIVIDUAL_RESPONSES%', individualResponsesFormatted).replace('%USER_PROMPT%', prompt); // Added %USER_PROMPT% for more flexibility

                                const collaborativeResponse = await fetchAIResponse(finalAggregationPrompt, defaultService, ROLES[defaultService] === 'custom' ? GM_getValue(STORAGE_PREFIX + defaultService + "_custom_role", "") : ROLES[defaultService]);

                                collabBox.removeChild(loadingMessageDiv); // Remove loading message

                                if (collaborativeResponse) {
                                    allResponses.push({ service: 'collaborative', result: collaborativeResponse.result });
                                }
                            }
                        }
                    }

                    saveSettings();
                    displayCollaboration(allResponses);

                } else if (!prompt.trim()) {
                    alert("Please enter a prompt.");
                } else {
                    alert("Please select at least one AI service to compare.");
                }
            };

            // --- Save Conversation Button ---
            const saveConversationButton = document.createElement("button");
            saveConversationButton.id = "save-conversation-button";
            saveConversationButton.innerText = "Save Conversation";
            inputArea.appendChild(saveConversationButton);
            saveConversationButton.onclick = () => {
                const conversationName = prompt("Enter a name for this conversation:");
                if (conversationName) {
                    savedConversations[conversationName] = conversationHistory;
                    GM_setValue(STORAGE_PREFIX + "saved_conversations", JSON.stringify(savedConversations));
                    loadSavedConversationsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-conversations-section"));
                    alert(`Conversation "${conversationName}" saved!`);
                }
            };

            // --- Saved Prompts Section ---
            const savedPromptsSection = document.createElement("div");
            savedPromptsSection.style.padding = "15px";
            savedPromptsSection.style.borderTop = "1px solid #eee";
            aiHubDiv.appendChild(savedPromptsSection);

            const savedPromptsHeader = document.createElement("h4");
            savedPromptsHeader.innerText = "💾 Saved Prompts";
            savedPromptsSection.appendChild(savedPromptsHeader);

            const savePromptInput = document.createElement("input");
            savePromptInput.type = "text";
            savePromptInput.placeholder = "Name this prompt";
            savePromptInput.style.width = "calc(100% - 80px)";
            savePromptInput.style.padding = "8px";
            savePromptInput.style.marginBottom = "5px";
            savePromptInput.style.borderRadius = "4px";
            savePromptInput.style.border = "1px solid #ced4da";
            savedPromptsSection.appendChild(savePromptInput);

            const savePromptButton = document.createElement("button");
            savePromptButton.innerText = "Save Prompt";
            applyButtonStyle(savePromptButton, { padding: '8px 10px', fontSize: '12px', backgroundColor: '#28a745', color: 'white', borderRadius: '4px', marginLeft: '5px' });
            savePromptButton.onclick = () => {
                const promptText = document.getElementById("ai-prompt-input").value;
                const promptName = savePromptInput.value.trim();
                if (promptText.trim() && promptName) {
                    savedPrompts[promptName] = promptText;
                    GM_setValue(STORAGE_PREFIX + "saved_prompts", JSON.stringify(savedPrompts));
                    savePromptInput.value = "";
                    loadSavedPromptsUI(savedPromptsSection);
                } else {
                    alert("Please enter a prompt and a name to save.");
                }
            };
            savedPromptsSection.appendChild(savePromptButton);

            const savedPromptsList = document.createElement("div");
            savedPromptsList.id = "saved-prompts-list";
            savedPromptsSection.appendChild(savedPromptsList);

            loadSavedPromptsUI(savedPromptsSection);

            // --- Saved Conversations Section ---
            const savedConversationsSection = document.createElement("div");
            savedConversationsSection.id = "saved-conversations-section";
            savedConversationsSection.style.padding = "15px";
            savedConversationsSection.style.borderTop = "1px solid #eee";
            aiHubDiv.appendChild(savedConversationsSection);

            const savedConversationsHeader = document.createElement("h4");
            savedConversationsHeader.innerText = "💾 Saved Conversations";
            savedConversationsSection.appendChild(savedConversationsHeader);

            const savedConversationsList = document.createElement("div");
            savedConversationsList.id = "saved-conversations-list";
            savedConversationsSection.appendChild(savedConversationsList);

            loadSavedConversationsUI(savedConversationsSection);

            // --- Saved Interactions Section ---
            const savedInteractionsSection = document.createElement("div");
            savedInteractionsSection.id = "saved-interactions-section";
            savedInteractionsSection.style.padding = "15px";
            savedInteractionsSection.style.borderTop = "1px solid #eee";
            aiHubDiv.appendChild(savedInteractionsSection);

            const savedInteractionsHeader = document.createElement("h4");
            savedInteractionsHeader.innerText = "💾 Saved Interactions";
            savedInteractionsSection.appendChild(savedInteractionsHeader);

            const savedInteractionsList = document.createElement("div");
            savedInteractionsList.id = "saved-interactions-list";
            savedInteractionsSection.appendChild(savedInteractionsList);

            loadSavedInteractionsUI(savedInteractionsSection);

            createSettingsPanel();
        } else {
            const templateSelect = aiHubDiv.querySelector("#prompt-template-select");
            if (templateSelect) {
                templateSelect.innerHTML = '<option value="">-- Select a Template --</option>';
                for (const name in promptTemplates) {
                    const option = document.createElement("option");
                    option.value = name;
                    option.innerText = name;
                    templateSelect.appendChild(option);
                }
            }
        }
    }

    function loadSavedConversationsUI(savedConversationsSection) {
        const savedConversationsList = savedConversationsSection.querySelector("#saved-conversations-list");
        if (savedConversationsList) {
            savedConversationsList.innerHTML = "";
            const savedConvos = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}"));
            for (const name in savedConvos) {
                const convoItem = document.createElement("div");
                convoItem.className = "conversation-item";
                convoItem.style.display = "flex";
                convoItem.style.alignItems = "center";
                convoItem.style.marginBottom = "5px";
                convoItem.style.padding = "5px";
                convoItem.style.borderRadius = "4px";
                convoItem.style.backgroundColor = "#f0f0f0";

                const loadButton = document.createElement("button");
                loadButton.innerText = name;
                applyButtonStyle(loadButton, { padding: '8px 12px', fontSize: '14px', backgroundColor: '#6c757d', color: 'white', margin: '5px', borderRadius: '5px', flexGrow: '1' });
                loadButton.onclick = () => loadConversation(name);
                convoItem.appendChild(loadButton);

                const renameButton = document.createElement("button");
                renameButton.innerText = "Rename";
                applyButtonStyle(renameButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#007bff', color: 'white', margin: '5px', borderRadius: '5px' });
                renameButton.onclick = () => {
                    const newName = prompt("Enter new name:", name);
                    if (newName && newName !== name) {
                        renameConversation(name, newName);
                    }
                };
                convoItem.appendChild(renameButton);

                const deleteButton = document.createElement("button");
                deleteButton.innerText = "Delete";
                applyButtonStyle(deleteButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#dc3545', color: 'white', margin: '5px', borderRadius: '5px' });
                deleteButton.onclick = () => { if (confirm(`Are you sure you want to delete conversation "${name}"?`)) { deleteConversation(name); } };
                convoItem.appendChild(deleteButton);

                savedConversationsList.appendChild(convoItem);
            }
            if (Object.keys(savedConvos).length === 0) {
                savedConversationsList.innerText = "No conversations saved yet.";
            }
        }
    }

    function loadConversation(conversationName) {
        const savedConvos = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}"));
        const conversation = savedConvos[conversationName];
        if (conversation) {
            conversationHistory = [...conversation]; // Load the conversation history
            const collabBox = document.getElementById("ai-collab-box");
            if (collabBox) {
                collabBox.innerHTML = ""; // Clear previous content
                conversation.forEach(item => {
                    const responseDiv = document.createElement("div");
                    const role = item.role === 'user' ? 'You' : item.role.toUpperCase();
                    responseDiv.innerHTML = `<b>${role}:</b> <div>${item.content}</div>`;
                    collabBox.appendChild(responseDiv);
                });
            }
            alert(`Conversation "${conversationName}" loaded.`);
        } else {
            alert("Conversation not found.");
        }
    }

    function renameConversation(oldName, newName) {
        const savedConvos = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}"));
        if (savedConvos[oldName]) {
            savedConvos[newName] = savedConvos[oldName];
            delete savedConvos[oldName];
            GM_setValue(STORAGE_PREFIX + "saved_conversations", JSON.stringify(savedConvos));
            loadSavedConversationsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-conversations-section"));
            alert(`Conversation "${oldName}" renamed to "${newName}".`);
        }
    }

    function deleteConversation(conversationName) {
        const savedConvos = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}"));
        delete savedConvos[conversationName];
        GM_setValue(STORAGE_PREFIX + "saved_conversations", JSON.stringify(savedConvos));
        loadSavedConversationsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-conversations-section"));
        alert(`Conversation "${conversationName}" deleted.`);
    }

    function loadSavedInteractionsUI(savedInteractionsSection) {
        const savedInteractionsList = savedInteractionsSection.querySelector("#saved-interactions-list");
        if (savedInteractionsList) {
            savedInteractionsList.innerHTML = "";
            const savedInts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_interactions", "{}"));
            for (const name in savedInts) {
                const interaction = savedInts[name];
                const interactionItem = document.createElement("div");
                interactionItem.className = "interaction-item";
                interactionItem.style.display = "flex";
                interactionItem.style.alignItems = "center";
                interactionItem.style.marginBottom = "5px";
                interactionItem.style.padding = "5px";
                interactionItem.style.borderRadius = "4px";
                interactionItem.style.backgroundColor = "#f0f0f0";

                const loadButton = document.createElement("button");
                loadButton.innerText = name;
                applyButtonStyle(loadButton, { padding: '8px 12px', fontSize: '14px', backgroundColor: '#6c757d', color: 'white', margin: '5px', borderRadius: '5px', flexGrow: '1' });
                loadButton.onclick = () => {
                    document.getElementById("ai-prompt-input").value = interaction.prompt;
                    displayCollaboration([{ service: interaction.service, result: interaction.response }]);
                };
                interactionItem.appendChild(loadButton);

                const renameButton = document.createElement("button");
                renameButton.innerText = "Rename";
                applyButtonStyle(renameButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#007bff', color: 'white', margin: '5px', borderRadius: '5px' });
                renameButton.onclick = () => {
                    const newName = prompt("Enter new name:", name);
                    if (newName && newName !== name) {
                        renameInteraction(name, newName);
                    }
                };
                interactionItem.appendChild(renameButton);

                const deleteButton = document.createElement("button");
                deleteButton.innerText = "Delete";
                applyButtonStyle(deleteButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#dc3545', color: 'white', margin: '5px', borderRadius: '5px' });
                deleteButton.onclick = () => { if (confirm(`Are you sure you want to delete interaction "${name}"?`)) { deleteInteraction(name); } };
                interactionItem.appendChild(deleteButton);

                savedInteractionsList.appendChild(interactionItem);
            }
            if (Object.keys(savedInts).length === 0) {
                savedInteractionsList.innerText = "No interactions saved yet.";
            }
        }
    }

    function saveInteraction(prompt, response, service) {
        const interactionName = prompt("Enter a name for this interaction:");
        if (interactionName) {
            savedInteractions[interactionName] = { prompt: prompt, response: response, service: service };
            GM_setValue(STORAGE_PREFIX + "saved_interactions", JSON.stringify(savedInteractions));
            loadSavedInteractionsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-interactions-section"));
            alert(`Interaction "${interactionName}" saved!`);
        }
    }

    function renameInteraction(oldName, newName) {
        const savedInts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_interactions", "{}"));
        if (savedInts[oldName]) {
            savedInts[newName] = savedInts[oldName];
            delete savedInts[oldName];
            GM_setValue(STORAGE_PREFIX + "saved_interactions", JSON.stringify(savedInts));
            loadSavedInteractionsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-interactions-section"));
            alert(`Interaction "${oldName}" renamed to "${newName}".`);
        }
    }

    function deleteInteraction(interactionName) {
        const savedInts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_interactions", "{}"));
        delete savedInts[interactionName];
        GM_setValue(STORAGE_PREFIX + "saved_interactions", JSON.stringify(savedInts));
        loadSavedInteractionsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-interactions-section"));
        alert(`Interaction "${interactionName}" deleted.`);
    }

    function displayCollaboration(responses) {
        const collabBox = document.getElementById("ai-collab-box");
        if (!collabBox) {
            const newCollabBox = document.createElement("div");
            newCollabBox.id = "ai-collab-box";
            const inputArea = document.querySelector("#ai-collaboration-hub > div"); // Assuming input area is the first div
            if (inputArea) {
                inputArea.parentNode.insertBefore(newCollabBox, inputArea.nextSibling);
            } else {
                document.getElementById("ai-collaboration-hub").appendChild(newCollabBox);
            }
            return displayCollaboration(responses); // Re-call after creating the box
        }

        responses.forEach(response => {
            const responseDiv = document.createElement("div");
            if (response.service === 'collaborative') {
                responseDiv.innerHTML = `<b>Collaborative Result:</b> <div>${response.result}</div>`;
            } else if (response.isSearchResult) {
                responseDiv.innerHTML = `<b>${response.service.toUpperCase()}:</b> <div>${response.result}</div>`;
            } else if (response.error) {
                responseDiv.innerHTML = `<b>${response.service.toUpperCase()}:</b> <div style="color: red;">Error: ${response.error}</div>`;
            } else {
                const responseContentDiv = document.createElement("div");
                responseContentDiv.innerText = response.result;
                responseDiv.appendChild(responseContentDiv);

                const controlsDiv = document.createElement("div"); // Container for buttons
                controlsDiv.style.display = "flex";
                controlsDiv.style.justifyContent = "flex-end";
                controlsDiv.style.marginTop = "5px";

                const saveButton = document.createElement("button");
                saveButton.innerText = "Save Interaction";
                saveButton.onclick = () => saveInteraction(document.getElementById("ai-prompt-input").value, response.result, response.service);
                controlsDiv.appendChild(saveButton);
                responseDiv.appendChild(controlsDiv);
            }
            collabBox.appendChild(responseDiv);
        });
        collabBox.scrollTop = collabBox.scrollHeight; // Scroll to bottom
    }

    function loadPromptTemplatesUI() {
        const templateListDiv = document.getElementById("prompt-templates-list");
        if (templateListDiv) {
            templateListDiv.innerHTML = "";
            for (const name in promptTemplates) {
                const templateItem = document.createElement("div");
                templateItem.className = "template-item";
                templateItem.style.display = "flex";
                templateItem.style.alignItems = "center";
                templateItem.style.marginBottom = "5px";
                templateItem.style.padding = "5px";
                templateItem.style.borderRadius = "4px";
                templateItem.style.backgroundColor = "#f0f0f0";

                const templateNameSpan = document.createElement("span");
                templateNameSpan.innerText = name;
                templateItem.appendChild(templateNameSpan);

                const editButton = document.createElement("button");
                editButton.innerText = "Edit";
                applyButtonStyle(editButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#007bff', color: 'white', margin: '5px', borderRadius: '5px' });
                editButton.onclick = () => showEditTemplateModal(name, promptTemplates[name]);
                templateItem.appendChild(editButton);

                const deleteButton = documentcreateElement("button");
                deleteButton.innerText = "Delete";
                applyButtonStyle(deleteButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#dc3545', color: 'white', margin: '5px', borderRadius: '5px' });
                deleteButton.onclick = () => { if (confirm(`Are you sure you want to delete template "${name}"?`)) { deletePromptTemplate(name); } };
                templateItem.appendChild(deleteButton);

                templateListDiv.appendChild(templateItem);
            }
            if (Object.keys(promptTemplates).length === 0) {
                templateListDiv.innerText = "No prompt templates saved yet.";
            }
        }
    }

    function showEditTemplateModal(templateName = "", templateText = "") {
        const modalId = "edit-template-modal";
        let modal = document.getElementById(modalId);

        if (!modal) {
            modal = document.createElement("div");
            modal.id = modalId;
            modal.style.cssText = `position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.2); z-index: 10002; font-family: sans-serif; font-size: 14px; width: 400px;`;
            const title = document.createElement("h3");
            title.innerText = `${templateName ? 'Edit' : 'Add'} Prompt Template`;
            modal.appendChild(title);
            const nameLabel = document.createElement("label");
            nameLabel.innerText = "Template Name:";
            nameLabel.style.display = "block";
            const nameInput = document.createElement("input");
            nameInput.type = "text";
            nameInput.id = "template-name-input";
            nameInput.style.width = "100%";
            nameInput.style.padding = "8px";
            nameInput.style.marginBottom = "10px";
            modal.appendChild(nameLabel);
            modal.appendChild(nameInput);
            const textLabel = document.createElement("label");
            textLabel.innerText = "Template Text:";
            textLabel.style.display = "block";
            const textTextarea = document.createElement("textarea");
            textTextarea.id = "template-text-textarea";
            textTextarea.style.width = "100%";
            textTextarea.style.minHeight = "100px";
            textTextarea.style.padding = "8px";
            textTextarea.style.marginBottom = "10px";
            modal.appendChild(textLabel);
            modal.appendChild(textTextarea);
            const saveBtn = document.createElement("button");
            saveBtn.innerText = "Save";
            applyButtonStyle(saveBtn, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#28a745', color: 'white', borderRadius: '5px', marginRight: '10px' });
            saveBtn.onclick = () => {
                const name = document.getElementById("template-name-input").value.trim();
                const text = document.getElementById("template-text-textarea").value.trim();
                if (name && text) {
                    savePromptTemplate(name, text, templateName);
                    document.body.removeChild(modal);
                } else {
                    alert("Please enter both a name and text for the template.");
                }
            };
            modal.appendChild(saveBtn);
            const cancelBtn = document.createElement("button");
            cancelBtn.innerText = "Cancel";
            applyButtonStyle(cancelBtn, { padding: '10px 15px', fontSize: '16px', backgroundColor: '#6c757d', color: 'white', borderRadius: '5px' });
            cancelBtn.onclick = () => document.body.removeChild(modal);
            modal.appendChild(cancelBtn);
            document.body.appendChild(modal);
        } else {
            modal.style.display = "block";
        }
        document.getElementById("template-name-input").value = templateName;
        document.getElementById("template-text-textarea").value = templateText;
    }

    function savePromptTemplate(name, text, oldName = "") {
        if (oldName && oldName !== name) {
            delete promptTemplates[oldName];
        }
        promptTemplates[name] = text;
        GM_setValue(STORAGE_PREFIX + "prompt_templates", JSON.stringify(promptTemplates));
        loadPromptTemplatesUI();
        const templateSelect = document.getElementById("prompt-template-select");
        if (templateSelect && templateSelect.querySelector(`option[value="${name}"]`)) {
            templateSelect.value = name;
        } else if (templateSelect) {
            const newOption = document.createElement("option");
            newOption.value = name;
            newOption.innerText = name;
            templateSelect.appendChild(newOption);
            templateSelect.value = name;
        }
    }

    function deletePromptTemplate(name) {
        if (confirm(`Are you sure you want to delete the template "${name}"?`)) {
            delete promptTemplates[name];
            GM_setValue(STORAGE_PREFIX + "prompt_templates", JSON.stringify(promptTemplates));
            loadPromptTemplatesUI();
            const templateSelect = document.getElementById("prompt-template-select");
            if (templateSelect && templateSelect.value === name) {
                templateSelect.value = "";
            }
        }
    }

    function exportSavedData() {
        const exportData = {
            savedConversations: JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_conversations", "{}")),
            savedInteractions: JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_interactions", "{}")),
            promptTemplates: JSON.parse(GM_getValue(STORAGE_PREFIX + "prompt_templates", "{}")),
            savedPrompts: JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_prompts", "{}"))
        };

        const jsonString = JSON.stringify(exportData, null, 2); // Use null, 2 for pretty printing

        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'aichub_export.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        alert("✅ Saved data exported to aichub_export.json");
    }

    function handleImportData() {
        const fileInput = document.getElementById("import-data-file");
        const file = fileInput.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const importedData = JSON.parse(e.target.result);
                    if (importedData) {
                        if (importedData.savedConversations) {
                            GM_setValue(STORAGE_PREFIX + "saved_conversations", JSON.stringify(importedData.savedConversations));
                            loadSavedConversationsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-conversations-section"));
                        }
                        if (importedData.savedInteractions) {
                            GM_setValue(STORAGE_PREFIX + "saved_interactions", JSON.stringify(importedData.savedInteractions));
                            loadSavedInteractionsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-interactions-section"));
                        }
                        if (importedData.promptTemplates) {
                            GM_setValue(STORAGE_PREFIX + "prompt_templates", JSON.stringify(importedData.promptTemplates));
                            loadPromptTemplatesUI();
                        }
                        if (importedData.savedPrompts) {
                            GM_setValue(STORAGE_PREFIX + "saved_prompts", JSON.stringify(importedData.savedPrompts));
                            loadSavedPromptsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-prompts-section"));
                        }
                        if (importedData.customAggregationPrompt !== undefined) {
                            SETTINGS.customAggregationPrompt = importedData.customAggregationPrompt;
                            GM_setValue(STORAGE_PREFIX + "custom_aggregation_prompt", SETTINGS.customAggregationPrompt);
                        }
                        alert("✅ Data imported successfully!");
                    } else {
                        alert("⚠️ Invalid data format in the imported file.");
                    }
                } catch (error) {
                    console.error("Error importing data:", error);
                    alert("⚠️ Could not import data. Please ensure the file is a valid AI Collaboration Hub export JSON file.");
                }
            };
            reader.readAsText(file);
        } else {
            alert("⚠️ Please select a file to import.");
        }
    }

    function loadSavedPromptsUI(savedPromptsSection) {
        const savedPromptsList = savedPromptsSection.querySelector("#saved-prompts-list");
        if (savedPromptsList) {
            savedPromptsList.innerHTML = "";
            const savedPrompts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_prompts", "{}"));
            for (const name in savedPrompts) {
                const promptContainer = document.createElement("div");
                promptContainer.className = "prompt-item";
                promptContainer.style.display = "flex";
                promptContainer.style.alignItems = "center";
                promptContainer.style.marginBottom = "5px";
                promptContainer.style.padding = "5px";
                promptContainer.style.borderRadius = "4px";
                promptContainer.style.backgroundColor = "#f0f0f0";

                const loadButton = document.createElement("button");
                loadButton.innerText = name;
                applyButtonStyle(loadButton, { padding: '8px 12px', fontSize: '14px', backgroundColor: '#6c757d', color: 'white', margin: '5px', borderRadius: '5px', flexGrow: '1' });
                loadButton.onclick = () => { document.getElementById("ai-prompt-input").value = savedPrompts[name]; };
                promptContainer.appendChild(loadButton);

                const deleteButton = document.createElement("button");
                deleteButton.innerText = "Delete";
                applyButtonStyle(deleteButton, { padding: '5px 8px', fontSize: '12px', backgroundColor: '#dc3545', color: 'white', margin: '5px', borderRadius: '5px' });
                deleteButton.onclick = () => { if (confirm(`Are you sure you want to delete prompt "${name}"?`)) { deleteSavedPrompt(name); } };
                promptContainer.appendChild(deleteButton);

                savedPromptsList.appendChild(promptContainer);
            }
            if (Object.keys(savedPrompts).length === 0) {
                savedPromptsList.innerText = "No prompts saved yet.";
            }
        }
    }

    function deleteSavedPrompt(name) {
        const savedPrompts = JSON.parse(GM_getValue(STORAGE_PREFIX + "saved_prompts", "{}"));
        delete savedPrompts[name];
        GM_setValue(STORAGE_PREFIX + "saved_prompts", JSON.stringify(savedPrompts));
        loadSavedPromptsUI(document.getElementById("ai-collaboration-hub").querySelector("#saved-prompts-section"));
    }

    // Helper function to apply consistent button styles
    function applyButtonStyle(button, styles) {
        for (const key in styles) {
            button.style[key] = styles[key];
        }
    }

    function registerContextMenuCommands() { /* Placeholder: Implement context menu commands */ }

    }

    const moduleInstance = new AICollaborationHubModule();

    if (typeof window !== 'undefined') {
        if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
            window.ModuleRegistry.register(moduleInstance);
        } else if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
            window.ChatGPTModules.register(moduleInstance);
        } else {
            initializeCollaborationHub();
        }
    }

})();
