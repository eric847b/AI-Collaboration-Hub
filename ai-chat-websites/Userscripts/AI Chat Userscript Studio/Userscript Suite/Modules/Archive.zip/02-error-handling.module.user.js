// ==UserScript==
// @name         2. Error Handling
// @version      2026.03.14.1
// @description  ChatGPT - Robust error handling with retries, logging, circuit breakers, and health monitoring.
// @author       AI RMD
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://poe.com/*
// @match        https://perplexity.ai/*
// @match        https://www.perplexity.ai/*
// @match        https://pi.ai/*
// @match        https://you.com/*
// @match        https://gemini.google.com/*
// @match        https://aistudio.google.com/*
// @match        https://copilot.microsoft.com/*
// @match        https://chat.mistral.ai/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_log
// @grant        GM_addStyle
// @require      https://cdn.jsdelivr.net/npm/@kudoai/chatgpt.js@latest/dist/chatgpt.min.js
// ==/UserScript==

(() => {
    'use strict';

    class ErrorHandlingModule {
        constructor() {
            this.name = 'ErrorHandling';
            this.version = '2026.03.14.1';
            this.dependencies = [];
            this.critical = false;
            this.config = {
                retry: {
                    maxRetries: 5,
                    baseDelay: 1000,
                    backoffFactor: 2,
                    maxConcurrent: 3,
                    throttleDelay: 5000,
                    maxDelay: 30000,
                    strategies: {}
                },
                circuitBreaker: {
                    threshold: 3,
                    timeout: 60000,
                    halfOpenMaxAttempts: 3,
                    resetTimeout: 120000,
                    failureThreshold: 0.6
                },
                logging: {
                    level: 'debug',
                    maxSize: 5242880,
                    retention: 86400000,
                    compression: true,
                    rotateCount: 3,
                    batchSize: 50,
                    flushInterval: 5000
                },
                healthCheck: {
                    interval: 300000,
                    errorRateThreshold: 0.5,
                    degradedThreshold: 0.7,
                    memoryThreshold: 0.9,
                    responseTimeThreshold: 5000
                }
            };
            
            this.state = {
                retries: 0,
                activeRetries: 0,
                circuitState: 'CLOSED',
                lastCircuitTrip: null,
                halfOpenAttempts: 0,
                metrics: {
                    totalErrors: 0,
                    retries: { attempted: 0, successful: 0, failed: 0 },
                    breakerTrips: 0,
                    consecutiveFailures: 0,
                    lastHealthCheck: null,
                    errorTypes: {},
                    responseTime: [],
                    memoryUsage: [],
                    lastCleanup: Date.now()
                }
            };
        }
        
        init() {
            if (window.ChatGPTConfig) {
                const savedConfig = window.ChatGPTConfig.get('errorHandling');
                if (savedConfig) {
                    this.config = { ...this.config, ...savedConfig };
                }
            }
            
            this.healthCheckInterval = setInterval(() => this.monitorHealth(), this.config.healthCheck.interval);
            this.logPruneInterval = setInterval(() => this.pruneLogs(), this.config.logging.retention);
            
            console.log('Error Handling module initialized');
        }

        destroy() {
            if (this.healthCheckInterval) {
                clearInterval(this.healthCheckInterval);
                this.healthCheckInterval = null;
            }
            if (this.logPruneInterval) {
                clearInterval(this.logPruneInterval);
                this.logPruneInterval = null;
            }
        }
        
        async handleRetry(errorType, action) {
            const strategy = this.config.retry.strategies?.[errorType] || {
                type: 'exponential',
                timeout: 10000
            };
            
            this.state.metrics.retries.attempted++;
            if (!this.state.metrics.errorTypes[errorType]) {
                this.state.metrics.errorTypes[errorType] = 0;
            }
            this.state.metrics.errorTypes[errorType]++;
            
            if (this.state.activeRetries >= this.config.retry.maxConcurrent) {
                this.log('warning', 'Max concurrent retries reached. Throttling...');
                await this.delay(this.config.retry.throttleDelay);
            }
            
            if (this.state.circuitState === 'OPEN') {
                const timeSinceTrip = Date.now() - this.state.lastCircuitTrip;
                if (timeSinceTrip < this.config.circuitBreaker.timeout) {
                    this.log('warning', 'Circuit breaker OPEN. Skipping retries.');
                    throw new Error('Circuit breaker is OPEN');
                }
                
                if (timeSinceTrip >= this.config.circuitBreaker.resetTimeout) {
                    this.state.circuitState = 'CLOSED';
                    this.log('info', 'Circuit breaker force reset to CLOSED due to timeout');
                } else {
                    this.state.circuitState = 'HALF-OPEN';
                    this.state.halfOpenAttempts = 0;
                    this.log('info', 'Circuit breaker transitioning to HALF-OPEN');
                }
            }
            
            this.state.activeRetries++;
            const startTime = Date.now();
            let lastError;
            
            for (let attempt = 1; attempt <= this.config.retry.maxRetries; attempt++) {
                try {
                    const timeoutPromise = new Promise((_, reject) => {
                        setTimeout(() => reject(new Error('Operation timed out')), strategy.timeout);
                    });
                    
                    const actionPromise = action();
                    const result = await Promise.race([actionPromise, timeoutPromise]);
                    
                    const responseTime = Date.now() - startTime;
                    this.state.metrics.responseTime.push(responseTime);
                    
                    if (this.state.metrics.responseTime.length > 100) {
                        this.state.metrics.responseTime = this.state.metrics.responseTime.slice(-100);
                    }
                    
                    if (this.state.circuitState === 'HALF-OPEN') {
                        this.state.halfOpenAttempts++;
                        if (this.state.halfOpenAttempts >= this.config.circuitBreaker.halfOpenMaxAttempts) {
                            this.state.circuitState = 'CLOSED';
                            this.log('info', 'Circuit breaker reset to CLOSED');
                        }
                    }
                    
                    this.state.metrics.retries.successful++;
                    this.state.metrics.consecutiveFailures = 0;
                    this.state.activeRetries--;
                    return result;
                    
                } catch (err) {
                    lastError = err;
                    this.log('error', `Retry #${attempt} failed`, { 
                        error: err, 
                        attempt, 
                        errorType,
                        responseTime: Date.now() - startTime
                    });
                    
                    this.state.metrics.retries.failed++;
                    this.state.metrics.consecutiveFailures++;
                    this.state.metrics.totalErrors++;

                    const failureRate = this.state.metrics.retries.failed / 
                        (this.state.metrics.retries.failed + this.state.metrics.retries.successful);
                    
                    if (failureRate >= this.config.circuitBreaker.failureThreshold || 
                        this.state.circuitState === 'HALF-OPEN' || 
                        attempt === this.config.retry.maxRetries) {
                        this.tripCircuitBreaker();
                        this.state.activeRetries--;
                        throw lastError;
                    }

                    if (typeof process !== 'undefined' && process.memoryUsage) {
                        const memUsage = process.memoryUsage();
                        this.state.metrics.memoryUsage.push({
                            timestamp: Date.now(),
                            usage: memUsage.heapUsed / memUsage.heapTotal
                        });

                        if (this.state.metrics.memoryUsage.length > 100) {
                            this.state.metrics.memoryUsage = this.state.metrics.memoryUsage.slice(-100);
                        }
                    }

                    await this.delay(this.calculateDelay(attempt, errorType));
                }
            }
            
            throw lastError;
        }

        tripCircuitBreaker() {
            this.state.circuitState = 'OPEN';
            this.state.lastCircuitTrip = Date.now();
            this.state.metrics.breakerTrips++;
            this.log('critical', 'Circuit breaker tripped!', {
                consecutiveFailures: this.state.metrics.consecutiveFailures,
                totalErrors: this.state.metrics.totalErrors,
                errorTypes: this.state.metrics.errorTypes,
                failureRate: this.state.metrics.retries.failed / 
                    (this.state.metrics.retries.failed + this.state.metrics.retries.successful)
            });
        }

        delay(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        calculateDelay(attempt, type) {
            const jitter = Math.random() * 0.3 + 0.85;
            const base = this.config.retry.baseDelay;
            const strategy = this.config.retry.strategies[type];
            
            let delay;
            if (strategy?.type === 'exponential') {
                delay = base * Math.pow(this.config.retry.backoffFactor, attempt - 1) * jitter;
            } else {
                delay = base * attempt * jitter;
            }

            return Math.min(delay, this.config.retry.maxDelay);
        }

        monitorHealth() {
            const now = Date.now();
            const errorRate = this.state.metrics.totalErrors / Math.max(this.state.metrics.retries.attempted, 1);
            const avgResponseTime = this.state.metrics.responseTime.length 
                ? this.state.metrics.responseTime.reduce((a, b) => a + b, 0) / this.state.metrics.responseTime.length 
                : 0;

            let memoryHealth = 'UNKNOWN';
            if (this.state.metrics.memoryUsage.length > 0) {
                const recentMemoryUsage = this.state.metrics.memoryUsage.slice(-5);
                const avgMemoryUsage = recentMemoryUsage.reduce((a, b) => a + b.usage, 0) / recentMemoryUsage.length;
                memoryHealth = avgMemoryUsage < this.config.healthCheck.memoryThreshold ? 'HEALTHY' : 'DEGRADED';
            }

            const health = {
                status: errorRate < this.config.healthCheck.errorRateThreshold && 
                        avgResponseTime < this.config.healthCheck.responseTimeThreshold ? 'HEALTHY' 
                    : errorRate < this.config.healthCheck.degradedThreshold ? 'DEGRADED' 
                    : 'CRITICAL',
                errorRate,
                avgResponseTime,
                memoryHealth,
                circuitState: this.state.circuitState,
                activeRetries: this.state.activeRetries,
                errorTypes: this.state.metrics.errorTypes,
                timestamp: now,
                metrics: {
                    successRate: this.state.metrics.retries.successful / Math.max(this.state.metrics.retries.attempted, 1),
                    breakerTrips: this.state.metrics.breakerTrips,
                    lastLogFlush: this.state.lastLogFlush
                }
            };

            this.state.metrics.lastHealthCheck = health;
            this.log('info', 'System Health Check', health);

            if (health.status === 'HEALTHY' && this.state.circuitState === 'OPEN' && 
                (now - this.state.lastCircuitTrip > this.config.circuitBreaker.timeout * 2)) {
                this.state.circuitState = 'HALF-OPEN';
                this.log('info', 'Circuit breaker auto-reset to HALF-OPEN due to sustained health');
            }

            if (now - this.state.metrics.lastCleanup > this.config.logging.retention) {
                this.cleanupMetrics();
                this.state.metrics.lastCleanup = now;
            }

            return health;
        }

        cleanupMetrics() {
            const now = Date.now();
            const retentionTime = this.config.logging.retention;

            this.state.metrics.responseTime = this.state.metrics.responseTime.filter(time => 
                now - time < retentionTime);

            if (this.state.metrics.memoryUsage.length > 0) {
                this.state.metrics.memoryUsage = this.state.metrics.memoryUsage.filter(entry =>
                    now - entry.timestamp < retentionTime);
            }

            this.log('debug', 'Metrics cleaned up', {
                responseTimesKept: this.state.metrics.responseTime.length,
                memoryMetricsKept: this.state.metrics.memoryUsage.length
            });
        }

        pruneLogs() {
            try {
                const storedLogs = typeof GM_getValue === 'function'
                    ? GM_getValue('errorLogs', '[]')
                    : '[]';
                const parsedLogs = typeof storedLogs === 'string' && storedLogs.trim()
                    ? JSON.parse(storedLogs)
                    : storedLogs;
                const logs = Array.isArray(parsedLogs) ? parsedLogs : [];
                const now = Date.now();
                
                const filteredLogs = logs.filter((log) => {
                    if (!log || !log.timestamp) return false;
                    const age = now - new Date(log.timestamp).getTime();
                    return age < this.config.logging.retention && age >= 0;
                });

                const compressedLogs = this.config.logging.compression ? 
                    JSON.stringify(filteredLogs).replace(/\s+/g, '') : 
                    JSON.stringify(filteredLogs);
                
                if (compressedLogs) {
                    GM_setValue('errorLogs', compressedLogs);
                }

                const rotationBatchSize = Math.min(10, this.config.logging.rotateCount);
                for (let i = 0; i < this.config.logging.rotateCount; i += rotationBatchSize) {
                    const batch = Array.from({ length: Math.min(rotationBatchSize, this.config.logging.rotateCount - i) }, (_, j) => i + j);
                    batch.forEach(index => {
                        try {
                            const key = `errorLogs_${Math.floor((now - index * this.config.logging.retention) / this.config.logging.retention)}`;
                            if (GM_getValue(key) !== undefined) {
                                GM_deleteValue(key);
                            }
                        } catch (e) {
                            // Silently continue if individual rotation deletion fails
                        }
                    });
                }

                this.log('debug', 'Logs pruned', { 
                    remainingLogs: filteredLogs.length,
                    timestamp: now
                });
            } catch (error) {
                this.log('error', 'Log pruning failed', { error: error.message, stack: error.stack });
            }
        }

        log(level, message, data = null) {
            if (window.ChatGPTUtils?.logger) {
                window.ChatGPTUtils.logger(level, `[ErrorHandling] ${message}`, data);
                return;
            }

            const method = typeof console[level] === 'function' ? level : 'log';
            console[method](`[ErrorHandling] ${message}`, data || '');
        }

        async main() {
            const healthCheckInterval = setInterval(() => {
                this.monitorHealth();
            }, this.config.healthCheck.interval);

            try {
                while (true) {
                    try {
                        this.log('info', 'Attempting action...');
                        const result = await this.handleRetry('api', async () => 'Success');
                        this.log('info', `Action successful: ${result}`);
                    } catch (e) {
                        this.log('critical', 'Action failed after retries', { error: e.message });
                    }
                    await this.delay(10000);
                }
            } catch (error) {
                this.log('error', 'Unexpected error in main function', { error: error.message });
            } finally {
                clearInterval(healthCheckInterval);
            }
        }
    }

    (function registerModule() {
        const attemptRegistration = () => {
            if (!window.ChatGPTModules) {
                return false;
            }

            const instance = new ErrorHandlingModule();
            window.ChatGPTModules.register(instance);
            instance.init();
            return true;
        };

        if (attemptRegistration()) {
            return;
        }

        const checkInterval = setInterval(() => {
            if (attemptRegistration()) {
                clearInterval(checkInterval);
            }
        }, 100);
    })();
            })();
