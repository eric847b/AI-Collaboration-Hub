// ==UserScript==
// @name         Sovereign Loader
// @namespace    http://tampermonkey.net/
// @version      2026.04.28.0
// @description  Auto-registers sovereign modules and activates the merge loop on AI chat pages
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://perplexity.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(function() {
  'use strict';

  class SovereignLoaderModule {
    constructor() {
      this.name = 'SovereignLoader';
      this.version = '2026.04.28.0';
      this.dependencies = [];
      this.critical = false;
    }

    init() {
      console.log('[SovereignLoader] Module initialized');
      
      // Register with SovereignEngine if available
      if (window.SovereignEngine) {
        this.registerSovereignModules();
      }
      
      return true;
    }

    registerSovereignModules() {
      // Desktop modules are registered via sovereign-merge-engine
      console.log('[SovereignLoader] Sovereign modules ready');
    }

    execute() {
      console.log('[SovereignLoader] Execute called');
    }

    onConfigUpdate(settings) {
      console.log('[SovereignLoader] Config updated:', settings);
    }

    destroy() {
      console.log('[SovereignLoader] Module destroyed');
    }
  }

  // Register with hub
  const instance = new SovereignLoaderModule();
  if (typeof window !== 'undefined') {
    if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
      window.ModuleRegistry.register(instance);
    } else if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
      window.ChatGPTModules.register(instance);
    }
  }
})();
