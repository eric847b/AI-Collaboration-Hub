// ==UserScript==
// @name         38. ChatGPT UI Cleanup .M
// @namespace    http://tampermonkey.net/
// @version      2026.04.28.0
// @description  ChatGPT UI cleanup module that hides intrusive popups and disclaimer banners
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://perplexity.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// ==/UserScript==

(function() {
    'use strict';

    class AIRMDUICleanupModule {
        constructor() {
            this.name = 'AIRMDUICleanup';
            this.version = '2026.03.28.1';
            this.dependencies = [];
            this.critical = false;
            this.config = {
                enabled: true,
                debounceMs: 200,
                hidePopups: true,
                removeDisclaimers: true
            };
            this.selectors = {
                popup: 'div[class*="rounded-2xl"][class*="border-token-border-light"][class*="bg-token-main-surface-primary"]',
                disclaimer: 'div[class*="relative"][class*="w-full"][class*="px-2"][class*="py-2"][class*="text-center"][class*="text-xs"][class*="text-token-text-secondary"] > span'
            };
            this.state = {
                observer: null,
                started: false,
                 scheduled: false,
               readyListenerRegistered: false
            };
            this.api = {
                cleanup: () => this.cleanup(),
                hidePopup: () => this.hidePopup(),
                removeDisclaimer: () => this.removeDisclaimer(),
                scheduleCleanup: () => this.scheduleCleanup(),
                startObserver: () => this.startObserver(),
                stopObserver: () => this.stopObserver(),
                setConfig: (settings) => this.setConfig(settings),
                getConfig: () => ({ ...this.config }),
                init: () => this.initApi()
            };
        }

        init() {
            if (window.ConfigManager && typeof window.ConfigManager.getConfig === 'function') {
                this.config = {
                    ...this.config,
                    ...window.ConfigManager.getConfig('airmduicleanup')
                };
            }

            window.AIRMDUICleanup = this.api;
            return this.api;
        }

        execute() {
            if (!this.config.enabled || this.state.started) {
                return;
            }

            this.state.started = true;

            if (document.readyState === 'loading') {
                if (this.state.readyListenerRegistered) {
                    return;
                }

                this.state.readyListenerRegistered = true;
                document.addEventListener('DOMContentLoaded', () => {
                    this.state.readyListenerRegistered = false;
                    this.startObserver();
                }, { once: true });
                return;
            }

            this.startObserver();
        }

        onConfigUpdate(settings) {
            this.setConfig(settings);
        }

        setConfig(settings = {}) {
            Object.assign(this.config, settings);

            if (this.config.enabled) {
                this.cleanup();
                this.startObserver();
            } else {
                this.stopObserver();
            }

            return { ...this.config };
        }

        hidePopup() {
            if (!this.config.hidePopups) {
                return false;
            }

            const popup = document.querySelector(this.selectors.popup);
            if (!popup) {
                return false;
            }

            popup.style.display = 'none';
            return true;
        }

        removeDisclaimer() {
            if (!this.config.removeDisclaimers) {
                return false;
            }

            const disclaimer = document.querySelector(this.selectors.disclaimer);
            if (!disclaimer || !disclaimer.parentElement) {
                return false;
            }

            disclaimer.parentElement.remove();
            return true;
        }

        cleanup() {
            if (!this.config.enabled) {
                return { popupHidden: false, disclaimerRemoved: false };
            }

            return {
                popupHidden: this.hidePopup(),
                disclaimerRemoved: this.removeDisclaimer()
            };
        }

        scheduleCleanup() {
            if (!this.config.enabled || this.state.scheduled) {
                return false;
            }

            this.state.scheduled = true;
            window.setTimeout(() => {
                this.state.scheduled = false;
                this.cleanup();
            }, this.config.debounceMs);

            return true;
        }

        startObserver() {
            if (!this.config.enabled || !document.body) {
                return false;
            }

            this.cleanup();

            if (this.state.observer) {
                return true;
            }

            this.state.observer = new MutationObserver(() => {
                this.scheduleCleanup();
            });

            this.state.observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            return true;
        }

        stopObserver() {
            if (this.state.observer) {
                this.state.observer.disconnect();
                this.state.observer = null;
            }

            this.state.started = false;
            this.state.scheduled = false;
            return true;
        }

        initApi() {
            return {
                enabled: this.config.enabled,
                observing: Boolean(this.state.observer),
                selectors: { ...this.selectors }
            };
        }

        destroy() {
            this.stopObserver();
        }
    }

    const instance = new AIRMDUICleanupModule();
    window.AIRMDUICleanupModule = instance;

    if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
        window.ModuleRegistry.register(instance);
    } else if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
        window.ChatGPTModules.register(instance);
    }

    instance.init();
    instance.execute();
})();
