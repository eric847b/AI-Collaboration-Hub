﻿// ==UserScript==
// @name         17. Reminder System .M
// @namespace    http://tampermonkey.net/
// @version      2026.04.28.0
// @description  Reminder system for setting AI chat session reminders and notifications
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://perplexity.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_notification
// ==/UserScript==

(function() {
  'use strict';

  class ReminderSystemModule {
    constructor() {
      this.name = 'ReminderSystem';
      this.version = '2026.04.28.0';
      this.dependencies = [];
      this.critical = false;
      this.reminders = [];
      this.checkInterval = null;
    }

    init() {
      console.log('[ReminderSystem] Module initialized');
      this.loadReminders();
      this.registerMenuCommands();
      this.startReminderCheck();
      return true;
    }

    loadReminders() {
      try {
        const stored = GM_getValue('aiReminders', '[]');
        this.reminders = JSON.parse(stored);
      } catch (e) {
        this.reminders = [];
      }
    }

    saveReminders() {
      try {
        GM_setValue('aiReminders', JSON.stringify(this.reminders));
      } catch (e) {
        console.warn('[ReminderSystem] Failed to save reminders:', e);
      }
    }

    addReminder(title, minutesFromNow) {
      const reminder = {
        id: Date.now(),
        title,
        triggerAt: Date.now() + (minutesFromNow * 60 * 1000),
        created: new Date().toISOString(),
        triggered: false
      };
      this.reminders.push(reminder);
      this.saveReminders();
      console.log('[ReminderSystem] Reminder added:', reminder.id, 'trigger in', minutesFromNow, 'minutes');
      return reminder;
    }

    checkReminders() {
      const now = Date.now();
      this.reminders.forEach(reminder => {
        if (!reminder.triggered && now >= reminder.triggerAt) {
          this.triggerReminder(reminder);
        }
      });
    }

    triggerReminder(reminder) {
      reminder.triggered = true;
      this.saveReminders();
      
      if (typeof GM_notification !== 'undefined') {
        GM_notification({
          title: 'AI Chat Reminder',
          text: reminder.title,
          timeout: 10000
        });
      }
      
      console.log('[ReminderSystem] Reminder triggered:', reminder.title);
    }

    clearReminder(reminderId) {
      this.reminders = this.reminders.filter(r => r.id !== reminderId);
      this.saveReminders();
      console.log('[ReminderSystem] Reminder cleared:', reminderId);
    }

    getActiveReminders() {
      return this.reminders.filter(r => !r.triggered);
    }

    registerMenuCommands() {
      if (typeof GM_registerMenuCommand !== 'undefined') {
        GM_registerMenuCommand('Reminder: Add 5 min', () => {
          const title = prompt('Reminder title:');
          if (title) this.addReminder(title, 5);
        });

        GM_registerMenuCommand('Reminder: Add 15 min', () => {
          const title = prompt('Reminder title:');
          if (title) this.addReminder(title, 15);
        });

        GM_registerMenuCommand('Reminder: List Active', () => {
          const active = this.getActiveReminders();
          const msg = active.length > 0 
            ? active.map(r => `- ${r.title} (${Math.round((r.triggerAt - Date.now())/60000)} min)`).join('\n')
            : 'No active reminders';
          alert(`Active Reminders:\n${msg}`);
        });
      }
    }

    startReminderCheck() {
      this.checkInterval = setInterval(() => this.checkReminders(), 30000);
    }

    execute() {
      console.log('[ReminderSystem] Execute called');
    }

    onConfigUpdate(settings) {
      console.log('[ReminderSystem] Config updated:', settings);
    }

    destroy() {
      if (this.checkInterval) {
        clearInterval(this.checkInterval);
      }
      console.log('[ReminderSystem] Module destroyed');
    }
  }

  // Register with hub
  const instance = new ReminderSystemModule();
  if (typeof window !== 'undefined') {
    if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
      window.ModuleRegistry.register(instance);
    } else if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
      window.ChatGPTModules.register(instance);
    }
  }
})();
