// ==UserScript==
// @name         Unified Configuration Manager Module
// @namespace    http://tampermonkey.net/
// @version      2026.03.21.1
// @description  Enterprise-grade unified configuration management with cloud sync, feature flags, A/B testing, and advanced validation
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://poe.com/*
// @match        https://perplexity.ai/*
// @match        https://www.perplexity.ai/*
// @match        https://pi.ai/*
// @match        https://you.com/*
// @match        https://gemini.google.com/*
// @match        https://aistudio.google.com/*
// @match        https://copilot.microsoft.com/*
// @match        https://chat.mistral.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_notification
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
// @noframes
// ==/UserScript==

/**
 * Unified Configuration Manager Module
 * 
 * Enterprise-grade configuration management system featuring:
 * - Unified configuration across all modules
 * - Cloud sync and backup capabilities
 * - Feature flags and A/B testing
 * - Advanced validation and type checking
 * - Import/export with version control
 * - Multi-platform configuration management
 * - Real-time configuration updates
 * - Configuration inheritance and overrides
 * - Environment-specific configurations
 * - Configuration encryption and security
 */

(function() {
    'use strict';

    const MODULE_NAME = 'Unified Configuration Manager';
    const MODULE_VERSION = '2026.03.21.1';
    const CONFIG_KEY = 'unifiedConfig';
    const CLOUD_SYNC_KEY = 'unifiedConfigCloudSync';
    const BACKUP_KEY = 'unifiedConfigBackup';
    const FEATURE_FLAGS_KEY = 'unifiedConfigFeatureFlags';
    const AB_TESTING_KEY = 'unifiedConfigABTesting';
    
    // Configuration schema
    const CONFIG_SCHEMA = {
        // Core system configuration
        system: {
            debugMode: { type: 'boolean', default: false, description: 'Enable debug logging' },
            theme: { type: 'string', default: 'system', enum: ['light', 'dark', 'system'], description: 'UI theme preference' },
            language: { type: 'string', default: 'en', description: 'Interface language' },
            autoSave: { type: 'boolean', default: true, description: 'Auto-save configuration changes' },
            autoSaveInterval: { type: 'number', default: 30000, min: 5000, max: 300000, description: 'Auto-save interval in milliseconds' },
            enableAnalytics: { type: 'boolean', default: false, description: 'Enable usage analytics' },
            privacyMode: { type: 'boolean', default: true, description: 'Enable privacy mode' },
            maxHistoryItems: { type: 'number', default: 1000, min: 100, max: 10000, description: 'Maximum history items to keep' }
        },
        
        // Performance configuration
        performance: {
            enablePerformanceMetrics: { type: 'boolean', default: true, description: 'Enable performance monitoring' },
            metricsRetentionDays: { type: 'number', default: 30, min: 1, max: 365, description: 'Performance metrics retention in days' },
            enableMemoryManagement: { type: 'boolean', default: true, description: 'Enable automatic memory management' },
            maxMemoryUsage: { type: 'number', default: 8192, min: 1024, max: 32768, description: 'Maximum memory usage in MB' },
            enableAutoOptimization: { type: 'boolean', default: true, description: 'Enable automatic optimization' },
            optimizationInterval: { type: 'number', default: 30000, min: 10000, max: 300000, description: 'Optimization interval in milliseconds' }
        },
        
        // Module configuration
        modules: {
            enableModuleRegistry: { type: 'boolean', default: true, description: 'Enable module registry' },
            enableAutoLoad: { type: 'boolean', default: true, description: 'Enable automatic module loading' },
            enableModuleValidation: { type: 'boolean', default: true, description: 'Enable module validation' },
            maxConcurrentModules: { type: 'number', default: 50, min: 10, max: 200, description: 'Maximum concurrent modules' },
            moduleLoadTimeout: { type: 'number', default: 30000, min: 5000, max: 120000, description: 'Module load timeout in milliseconds' }
        },
        
        // Cache configuration
        cache: {
            enableCache: { type: 'boolean', default: true, description: 'Enable caching' },
            cacheExpiration: { type: 'number', default: 3600, min: 300, max: 86400, description: 'Cache expiration in seconds' },
            maxCacheSize: { type: 'number', default: 2000, min: 100, max: 10000, description: 'Maximum cache size' },
            enableCompression: { type: 'boolean', default: false, description: 'Enable cache compression' },
            enableEncryption: { type: 'boolean', default: false, description: 'Enable cache encryption' }
        },
        
        // Network configuration
        network: {
            maxConcurrentRequests: { type: 'number', default: 32, min: 4, max: 128, description: 'Maximum concurrent network requests' },
            requestTimeout: { type: 'number', default: 120000, min: 10000, max: 600000, description: 'Request timeout in milliseconds' },
            enableRetry: { type: 'boolean', default: true, description: 'Enable request retry' },
            maxRetries: { type: 'number', default: 3, min: 0, max: 10, description: 'Maximum retry attempts' },
            retryDelay: { type: 'number', default: 1000, min: 100, max: 10000, description: 'Retry delay in milliseconds' },
            enableRateLimiting: { type: 'boolean', default: true, description: 'Enable rate limiting' },
            rateLimitWindow: { type: 'number', default: 60000, min: 10000, max: 300000, description: 'Rate limit window in milliseconds' },
            rateLimitMaxRequests: { type: 'number', default: 100, min: 10, max: 1000, description: 'Maximum requests per rate limit window' }
        },
        
        // Security configuration
        security: {
            enableSecurityAudit: { type: 'boolean', default: true, description: 'Enable security audit logging' },
            auditLogRetention: { type: 'number', default: 90, min: 7, max: 365, description: 'Audit log retention in days' },
            enableFailover: { type: 'boolean', default: true, description: 'Enable failover mechanisms' },
            enableLoadBalancing: { type: 'boolean', default: false, description: 'Enable load balancing' },
            enableErrorBoundary: { type: 'boolean', default: true, description: 'Enable error boundary protection' }
        },
        
        // Cloud sync configuration
        cloudSync: {
            enableCloudSync: { type: 'boolean', default: false, description: 'Enable cloud synchronization' },
            cloudSyncEndpoint: { type: 'string', default: '', description: 'Cloud sync endpoint URL' },
            cloudSyncInterval: { type: 'number', default: 300000, min: 60000, max: 86400000, description: 'Cloud sync interval in milliseconds' },
            enableAutoBackup: { type: 'boolean', default: true, description: 'Enable automatic backups' },
            backupInterval: { type: 'number', default: 86400000, min: 3600000, max: 604800000, description: 'Backup interval in milliseconds' },
            maxBackups: { type: 'number', default: 7, min: 1, max: 30, description: 'Maximum number of backups to keep' }
        },
        
        // Feature flags configuration
        featureFlags: {
            enableFeatureFlags: { type: 'boolean', default: true, description: 'Enable feature flags system' },
            enableABTesting: { type: 'boolean', default: false, description: 'Enable A/B testing' },
            enableRemoteConfig: { type: 'boolean', default: false, description: 'Enable remote configuration' },
            remoteConfigEndpoint: { type: 'string', default: '', description: 'Remote configuration endpoint URL' },
            remoteConfigInterval: { type: 'number', default: 3600000, min: 300000, max: 86400000, description: 'Remote config check interval in milliseconds' }
        }
    };

    // Default configuration
    const DEFAULT_CONFIG = {
        version: MODULE_VERSION,
        timestamp: Date.now(),
        environment: 'production',
        modules: {},
        featureFlags: {},
        abTests: {},
        backups: [],
        cloudSync: {
            enabled: false,
            lastSync: null,
            pendingChanges: []
        }
    };

    /**
     * Unified Configuration Manager Class
     */
    class UnifiedConfigManager {
        constructor() {
            this.name = MODULE_NAME;
            this.version = MODULE_VERSION;
            this.dependencies = [];
            
            // State management
            this.state = {
                isActive: false,
                config: new Map(),
                schema: CONFIG_SCHEMA,
                validators: new Map(),
                listeners: new Map(),
                featureFlags: new Map(),
                abTests: new Map(),
                cloudSync: null,
                backupManager: null,
                validationErrors: new Map()
            };

            this.init();
        }

        /**
         * Initialize the unified configuration manager
         */
        async init() {
            try {
                console.log(`[${MODULE_NAME}] Initializing Unified Configuration Manager v${MODULE_VERSION}`);
                
                // Load configuration
                await this.loadConfiguration();
                
                // Initialize cloud sync
                this.initializeCloudSync();
                
                // Initialize backup manager
                this.initializeBackupManager();
                
                // Initialize feature flags
                this.initializeFeatureFlags();
                
                // Initialize A/B testing
                this.initializeABTesting();
                
                // Register with module registry
                if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
                    window.ModuleRegistry.register(this);
                }

                // Register menu commands
                this.registerMenuCommands();
                
                console.log(`[${MODULE_NAME}] Unified Configuration Manager initialized successfully`);
                this.state.isActive = true;
                
            } catch (error) {
                console.error(`[${MODULE_NAME}] Initialization failed:`, error);
                this.state.isActive = false;
            }
        }

        /**
         * Load configuration from storage
         */
        async loadConfiguration() {
            try {
                const storedConfig = GM_getValue(CONFIG_KEY);
                if (storedConfig) {
                    const config = JSON.parse(storedConfig);
                    this.state.config = new Map(Object.entries(config));
                    console.log(`[${MODULE_NAME}] Loaded configuration with ${this.state.config.size} entries`);
                } else {
                    // Initialize with defaults
                    this.initializeDefaults();
                }
            } catch (error) {
                console.warn(`[${MODULE_NAME}] Could not load configuration:`, error);
                this.initializeDefaults();
            }
        }

        /**
         * Initialize default configuration
         */
        initializeDefaults() {
            // Flatten schema to create default configuration
            const defaults = this.flattenSchema(CONFIG_SCHEMA);
            this.state.config = new Map(Object.entries(defaults));
            
            // Add system defaults
            this.state.config.set('version', MODULE_VERSION);
            this.state.config.set('timestamp', Date.now());
            this.state.config.set('environment', 'production');
            
            console.log(`[${MODULE_NAME}] Initialized default configuration`);
        }

        /**
         * Flatten schema to create default configuration
         */
        flattenSchema(schema, prefix = '') {
            const defaults = {};
            
            for (const [key, definition] of Object.entries(schema)) {
                const fullKey = prefix ? `${prefix}.${key}` : key;
                
                if (typeof definition === 'object' && !definition.type) {
                    // Nested object
                    Object.assign(defaults, this.flattenSchema(definition, fullKey));
                } else if (typeof definition === 'object' && definition.type) {
                    // Leaf node with type
                    defaults[fullKey] = definition.default;
                }
            }
            
            return defaults;
        }

        /**
         * Get configuration value
         */
        get(key, defaultValue = undefined) {
            if (!key) return Object.fromEntries(this.state.config);
            
            const value = this.state.config.get(key);
            if (value !== undefined) {
                return value;
            }
            
            // Try to find in schema for default
            const schemaValue = this.getSchemaValue(key);
            return schemaValue !== undefined ? schemaValue : defaultValue;
        }

        /**
         * Get schema value for a key
         */
        getSchemaValue(key) {
            const keys = key.split('.');
            let current = CONFIG_SCHEMA;
            
            for (const k of keys) {
                if (current && typeof current === 'object' && current[k]) {
                    current = current[k];
                } else {
                    return undefined;
                }
            }
            
            return current && current.default !== undefined ? current.default : undefined;
        }

        /**
         * Set configuration value
         */
        set(key, value) {
            // Validate value
            const validation = this.validateValue(key, value);
            if (!validation.valid) {
                console.warn(`[${MODULE_NAME}] Invalid value for ${key}:`, validation.errors);
                this.state.validationErrors.set(key, validation.errors);
                return false;
            }
            
            // Clear validation errors if valid
            this.state.validationErrors.delete(key);
            
            // Set value
            this.state.config.set(key, value);
            
            // Auto-save if enabled
            if (this.get('system.autoSave')) {
                this.saveConfiguration();
            }
            
            // Notify listeners
            this.notifyListeners(key, value);
            
            return true;
        }

        /**
         * Validate configuration value
         */
        validateValue(key, value) {
            const schema = this.getSchemaDefinition(key);
            if (!schema) {
                return { valid: true, errors: [] };
            }
            
            const errors = [];
            
            // Type validation
            if (schema.type) {
                const validType = this.validateType(value, schema.type);
                if (!validType) {
                    errors.push(`Invalid type. Expected ${schema.type}, got ${typeof value}`);
                }
            }
            
            // Enum validation
            if (schema.enum && !schema.enum.includes(value)) {
                errors.push(`Invalid value. Must be one of: ${schema.enum.join(', ')}`);
            }
            
            // Range validation for numbers
            if (schema.type === 'number') {
                if (schema.min !== undefined && value < schema.min) {
                    errors.push(`Value must be at least ${schema.min}`);
                }
                if (schema.max !== undefined && value > schema.max) {
                    errors.push(`Value must be at most ${schema.max}`);
                }
            }
            
            // String length validation
            if (schema.type === 'string' && schema.maxLength !== undefined && value.length > schema.maxLength) {
                errors.push(`String too long. Maximum length is ${schema.maxLength}`);
            }
            
            return {
                valid: errors.length === 0,
                errors
            };
        }

        /**
         * Validate type
         */
        validateType(value, expectedType) {
            switch (expectedType) {
                case 'string':
                    return typeof value === 'string';
                case 'number':
                    return typeof value === 'number' && isFinite(value);
                case 'boolean':
                    return typeof value === 'boolean';
                case 'object':
                    return typeof value === 'object' && value !== null;
                case 'array':
                    return Array.isArray(value);
                default:
                    return true;
            }
        }

        /**
         * Get schema definition for a key
         */
        getSchemaDefinition(key) {
            const keys = key.split('.');
            let current = CONFIG_SCHEMA;
            
            for (const k of keys) {
                if (current && typeof current === 'object' && current[k]) {
                    current = current[k];
                } else {
                    return undefined;
                }
            }
            
            return current && typeof current === 'object' && current.type ? current : undefined;
        }

        /**
         * Save configuration to storage
         */
        saveConfiguration() {
            try {
                const config = Object.fromEntries(this.state.config);
                GM_setValue(CONFIG_KEY, JSON.stringify(config));
                console.log(`[${MODULE_NAME}] Configuration saved`);
            } catch (error) {
                console.error(`[${MODULE_NAME}] Failed to save configuration:`, error);
            }
        }

        /**
         * Add configuration listener
         */
        addListener(key, callback) {
            if (!this.state.listeners.has(key)) {
                this.state.listeners.set(key, new Set());
            }
            this.state.listeners.get(key).add(callback);
            
            return () => this.removeListener(key, callback);
        }

        /**
         * Remove configuration listener
         */
        removeListener(key, callback) {
            if (this.state.listeners.has(key)) {
                this.state.listeners.get(key).delete(callback);
            }
        }

        /**
         * Notify listeners of configuration change
         */
        notifyListeners(key, value) {
            if (this.state.listeners.has(key)) {
                for (const callback of this.state.listeners.get(key)) {
                    try {
                        callback(key, value);
                    } catch (error) {
                        console.error(`[${MODULE_NAME}] Listener error for ${key}:`, error);
                    }
                }
            }
        }

        /**
         * Initialize cloud sync
         */
        initializeCloudSync() {
            this.state.cloudSync = {
                enabled: this.get('cloudSync.enableCloudSync'),
                endpoint: this.get('cloudSync.cloudSyncEndpoint'),
                interval: this.get('cloudSync.cloudSyncInterval'),
                lastSync: null,
                pendingChanges: [],
                timer: null
            };
            
            if (this.state.cloudSync.enabled && this.state.cloudSync.endpoint) {
                this.startCloudSync();
            }
        }

        /**
         * Start cloud sync
         */
        startCloudSync() {
            if (this.state.cloudSync.timer) return;
            
            this.state.cloudSync.timer = setInterval(() => {
                this.syncToCloud();
            }, this.state.cloudSync.interval);
            
            console.log(`[${MODULE_NAME}] Cloud sync started with interval ${this.state.cloudSync.interval}ms`);
        }

        /**
         * Stop cloud sync
         */
        stopCloudSync() {
            if (this.state.cloudSync.timer) {
                clearInterval(this.state.cloudSync.timer);
                this.state.cloudSync.timer = null;
            }
        }

        /**
         * Sync configuration to cloud
         */
        async syncToCloud() {
            if (!this.state.cloudSync.enabled || !this.state.cloudSync.endpoint) return;
            
            try {
                const config = Object.fromEntries(this.state.config);
                const payload = {
                    config,
                    timestamp: Date.now(),
                    version: MODULE_VERSION
                };
                
                const response = await this.makeRequest(this.state.cloudSync.endpoint + '/sync', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                
                if (response.ok) {
                    this.state.cloudSync.lastSync = Date.now();
                    this.state.cloudSync.pendingChanges = [];
                    console.log(`[${MODULE_NAME}] Configuration synced to cloud`);
                } else {
                    throw new Error(`Sync failed: ${response.status}`);
                }
            } catch (error) {
                console.error(`[${MODULE_NAME}] Cloud sync failed:`, error);
                this.state.cloudSync.pendingChanges.push({
                    timestamp: Date.now(),
                    error: error.message
                });
            }
        }

        /**
         * Initialize backup manager
         */
        initializeBackupManager() {
            this.state.backupManager = {
                enabled: this.get('cloudSync.enableAutoBackup'),
                interval: this.get('cloudSync.backupInterval'),
                maxBackups: this.get('cloudSync.maxBackups'),
                timer: null
            };
            
            if (this.state.backupManager.enabled) {
                this.startBackupManager();
            }
        }

        /**
         * Start backup manager
         */
        startBackupManager() {
            if (this.state.backupManager.timer) return;
            
            this.state.backupManager.timer = setInterval(() => {
                this.createBackup();
            }, this.state.backupManager.interval);
        }

        /**
         * Stop backup manager
         */
        stopBackupManager() {
            if (this.state.backupManager.timer) {
                clearInterval(this.state.backupManager.timer);
                this.state.backupManager.timer = null;
            }
        }

        /**
         * Create configuration backup
         */
        createBackup() {
            try {
                const backup = {
                    config: Object.fromEntries(this.state.config),
                    timestamp: Date.now(),
                    version: MODULE_VERSION,
                    environment: this.get('environment')
                };
                
                const backups = this.getBackups();
                backups.push(backup);
                
                // Limit backup count
                if (backups.length > this.state.backupManager.maxBackups) {
                    backups.shift();
                }
                
                GM_setValue(BACKUP_KEY, JSON.stringify(backups));
                console.log(`[${MODULE_NAME}] Configuration backup created`);
            } catch (error) {
                console.error(`[${MODULE_NAME}] Backup creation failed:`, error);
            }
        }

        /**
         * Get configuration backups
         */
        getBackups() {
            try {
                const stored = GM_getValue(BACKUP_KEY, '[]');
                return JSON.parse(stored);
            } catch (error) {
                console.warn(`[${MODULE_NAME}] Could not load backups:`, error);
                return [];
            }
        }

        /**
         * Restore from backup
         */
        restoreBackup(index) {
            const backups = this.getBackups();
            if (index < 0 || index >= backups.length) {
                throw new Error('Invalid backup index');
            }
            
            const backup = backups[index];
            this.state.config = new Map(Object.entries(backup.config));
            this.saveConfiguration();
            
            console.log(`[${MODULE_NAME}] Restored from backup ${index}`);
            return true;
        }

        /**
         * Initialize feature flags
         */
        initializeFeatureFlags() {
            try {
                const stored = GM_getValue(FEATURE_FLAGS_KEY, '{}');
                const flags = JSON.parse(stored);
                this.state.featureFlags = new Map(Object.entries(flags));
            } catch (error) {
                console.warn(`[${MODULE_NAME}] Could not load feature flags:`, error);
                this.state.featureFlags = new Map();
            }
        }

        /**
         * Check if feature flag is enabled
         */
        isFeatureEnabled(flagName, context = {}) {
            if (!this.get('featureFlags.enableFeatureFlags')) {
                return false;
            }
            
            const flag = this.state.featureFlags.get(flagName);
            if (!flag) return false;
            
            // Check conditions
            if (flag.conditions) {
                return this.evaluateConditions(flag.conditions, context);
            }
            
            return flag.enabled || false;
        }

        /**
         * Set feature flag
         */
        setFeatureFlag(flagName, config) {
            this.state.featureFlags.set(flagName, config);
            this.saveFeatureFlags();
        }

        /**
         * Save feature flags
         */
        saveFeatureFlags() {
            try {
                const flags = Object.fromEntries(this.state.featureFlags);
                GM_setValue(FEATURE_FLAGS_KEY, JSON.stringify(flags));
            } catch (error) {
                console.warn(`[${MODULE_NAME}] Could not save feature flags:`, error);
            }
        }

        /**
         * Initialize A/B testing
         */
        initializeABTesting() {
            try {
                const stored = GM_getValue(AB_TESTING_KEY, '{}');
                const tests = JSON.parse(stored);
                this.state.abTests = new Map(Object.entries(tests));
            } catch (error) {
                console.warn(`[${MODULE_NAME}] Could not load A/B tests:`, error);
                this.state.abTests = new Map();
            }
        }

        /**
         * Get A/B test variant
         */
        getABTestVariant(testName, userId = null) {
            if (!this.get('featureFlags.enableABTesting')) {
                return null;
            }
            
            const test = this.state.abTests.get(testName);
            if (!test || !test.enabled) {
                return null;
            }
            
            // Generate user ID if not provided
            if (!userId) {
                userId = this.generateUserId();
            }
            
            // Determine variant based on user ID
            const hash = this.hashString(userId + testName);
            const variantIndex = hash % test.variants.length;
            
            return test.variants[variantIndex];
        }

        /**
         * Generate user ID
         */
        generateUserId() {
            return GM_getValue('userId') || this.generateRandomId();
        }

        /**
         * Generate random ID
         */
        generateRandomId() {
            const id = Math.random().toString(36).substr(2, 9);
            GM_setValue('userId', id);
            return id;
        }

        /**
         * Hash string
         */
        hashString(str) {
            let hash = 0;
            for (let i = 0; i < str.length; i++) {
                const char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash; // Convert to 32-bit integer
            }
            return Math.abs(hash);
        }

        /**
         * Evaluate conditions
         */
        evaluateConditions(conditions, context) {
            for (const condition of conditions) {
                if (!this.evaluateCondition(condition, context)) {
                    return false;
                }
            }
            return true;
        }

        /**
         * Evaluate single condition
         */
        evaluateCondition(condition, context) {
            const { type, operator, value } = condition;
            const contextValue = context[type];

            switch (operator) {
                case 'eq': return contextValue === value;
                case 'ne': return contextValue !== value;
                case 'gt': return contextValue > value;
                case 'lt': return contextValue < value;
                case 'gte': return contextValue >= value;
                case 'lte': return contextValue <= value;
                case 'in': return Array.isArray(value) && value.includes(contextValue);
                case 'nin': return Array.isArray(value) && !value.includes(contextValue);
                default: return false;
            }
        }

        /**
         * Make HTTP request
         */
        async makeRequest(url, options = {}) {
            return new Promise((resolve, reject) => {
                GM_xmlhttpRequest({
                    method: options.method || 'GET',
                    url: url,
                    headers: options.headers || {},
                    data: options.body,
                    onload: resolve,
                    onerror: reject,
                    ontimeout: reject
                });
            });
        }

        /**
         * Get configuration report
         */
        getConfigurationReport() {
            return {
                active: this.state.isActive,
                configSize: this.state.config.size,
                featureFlagsCount: this.state.featureFlags.size,
                abTestsCount: this.state.abTests.size,
                validationErrors: Array.from(this.state.validationErrors.entries()),
                cloudSync: {
                    enabled: this.state.cloudSync.enabled,
                    lastSync: this.state.cloudSync.lastSync,
                    pendingChanges: this.state.cloudSync.pendingChanges.length
                },
                backups: {
                    count: this.getBackups().length,
                    maxBackups: this.state.backupManager.maxBackups
                },
                schema: Object.keys(CONFIG_SCHEMA).length
            };
        }

        /**
         * Export configuration
         */
        exportConfiguration() {
            const config = {
                config: Object.fromEntries(this.state.config),
                featureFlags: Object.fromEntries(this.state.featureFlags),
                abTests: Object.fromEntries(this.state.abTests),
                schema: CONFIG_SCHEMA,
                metadata: {
                    version: MODULE_VERSION,
                    timestamp: Date.now(),
                    environment: this.get('environment'),
                    exportType: 'unified-config'
                }
            };
            
            return JSON.stringify(config, null, 2);
        }

        /**
         * Import configuration
         */
        importConfiguration(configData) {
            try {
                const config = JSON.parse(configData);
                
                if (config.config) {
                    this.state.config = new Map(Object.entries(config.config));
                }
                
                if (config.featureFlags) {
                    this.state.featureFlags = new Map(Object.entries(config.featureFlags));
                }
                
                if (config.abTests) {
                    this.state.abTests = new Map(Object.entries(config.abTests));
                }
                
                this.saveConfiguration();
                this.saveFeatureFlags();
                
                console.log(`[${MODULE_NAME}] Configuration imported successfully`);
                return true;
            } catch (error) {
                console.error(`[${MODULE_NAME}] Configuration import failed:`, error);
                return false;
            }
        }

        /**
         * Reset configuration to defaults
         */
        resetToDefaults() {
            this.initializeDefaults();
            this.saveConfiguration();
            console.log(`[${MODULE_NAME}] Configuration reset to defaults`);
        }

        /**
         * Register menu commands
         */
        registerMenuCommands() {
            if (typeof GM_registerMenuCommand === 'function') {
                GM_registerMenuCommand(`Show ${MODULE_NAME} Report`, () => {
                    const report = this.getConfigurationReport();
                    console.table(report);
                    alert(`Configuration Report: ${JSON.stringify(report, null, 2)}`);
                });

                GM_registerMenuCommand(`Export Configuration`, () => {
                    const config = this.exportConfiguration();
                    const blob = new Blob([config], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `unified-config-${new Date().toISOString().split('T')[0]}.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                    alert('Configuration exported');
                });

                GM_registerMenuCommand(`Import Configuration`, () => {
                    const config = prompt('Paste configuration JSON:');
                    if (config) {
                        const success = this.importConfiguration(config);
                        alert(success ? 'Configuration imported successfully' : 'Import failed');
                    }
                });

                GM_registerMenuCommand(`Reset to Defaults`, () => {
                    if (confirm('Are you sure you want to reset configuration to defaults?')) {
                        this.resetToDefaults();
                        alert('Configuration reset to defaults');
                    }
                });

                GM_registerMenuCommand(`Show Feature Flags`, () => {
                    const flags = Object.fromEntries(this.state.featureFlags);
                    console.table(flags);
                    alert(`Feature Flags: ${JSON.stringify(flags, null, 2)}`);
                });

                GM_registerMenuCommand(`Show A/B Tests`, () => {
                    const tests = Object.fromEntries(this.state.abTests);
                    console.table(tests);
                    alert(`A/B Tests: ${JSON.stringify(tests, null, 2)}`);
                });
            }
        }

        /**
         * Cleanup and destroy
         */
        destroy() {
            console.log(`[${MODULE_NAME}] Destroying Unified Configuration Manager`);

            // Stop timers
            this.stopCloudSync();
            this.stopBackupManager();

            // Save final state
            this.saveConfiguration();
            this.saveFeatureFlags();

            this.state.isActive = false;
            console.log(`[${MODULE_NAME}] Unified Configuration Manager destroyed`);
        }

        /**
         * Execute module
         */
        execute() {
            // Module execution logic if needed
            console.log(`[${MODULE_NAME}] Module execution completed`);
        }
    }

    // Initialize the module
    const unifiedConfigManager = new UnifiedConfigManager();

    // Make globally available
    window.UnifiedConfigManager = unifiedConfigManager;

})();