// ==UserScript==
// @name         42. Network Optimization .M
// @namespace    http://tampermonkey.net/
// @version      2026.04.28.0
// @description  Advanced network optimization helpers for AI chat with intelligent caching, compression, and bandwidth management
// @author       AI RMD
// @license      MIT
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @match        https://claude.ai/*
// @match        https://perplexity.ai/*
// @grant        GM_getValue
// @grant        GM_setValue
// @require      https://cdnjs.cloudflare.com/ajax/libs/lz-string/1.4.4/lz-string.min.js
// @connect      cdnjs.cloudflare.com
// ==/UserScript==

(function() {
  'use strict';

  class NetworkOptimizationModule {
    constructor() {
      this.name = 'AIRMDNetworkOptimization';
      this.version = '2026.03.28.2';
      this.dependencies = [];
      this.critical = false;
      this.config = {
        autoOptimize: false,
        observeImages: true,
        intelligentCaching: true,
        bandwidthDetection: true,
        adaptiveLoading: true,
        compressionLevel: 'auto',
        cacheTTL: 300000, // 5 minutes
        maxCacheSize: 50, // MB
        retryAttempts: 3,
        retryDelay: 1000,
        priorityQueue: true,
        networkAwareness: true
      };
      this._observers = new Set();
      this._cache = new Map();
      this._requestQueue = [];
      this._bandwidthInfo = null;
      this._metrics = {
        requests: 0,
        cached: 0,
        compressed: 0,
        failed: 0,
        totalSize: 0,
        compressedSize: 0
      };
      this._compressionAlgorithms = {
        lzString: this._compressWithLZString.bind(this),
        base64: this._compressWithBase64.bind(this),
        custom: this._compressWithCustom.bind(this)
      };
      this.api = {
        lazyLoadImages: (root) => this.lazyLoadImages(root),
        compressText: (text, algorithm) => this.compressText(text, algorithm),
        decompressText: (text, algorithm) => this.decompressText(text, algorithm),
        init: (options) => this.initApi(options),
        // New API methods
        intelligentCache: {
          get: (key) => this._getCachedData(key),
          set: (key, data, ttl) => this._setCachedData(key, data, ttl),
          clear: () => this._clearCache(),
          stats: () => this._getCacheStats()
        },
        bandwidth: {
          detect: () => this._detectBandwidth(),
          getInfo: () => this._bandwidthInfo,
          isSlow: () => this._isSlowConnection()
        },
        compression: {
          available: () => this._getAvailableCompression(),
          benchmark: (text) => this._benchmarkCompression(text)
        },
        queue: {
          add: (request) => this._addToQueue(request),
          process: () => this._processQueue(),
          clear: () => this._clearQueue()
        },
        metrics: {
          get: () => this._getMetrics(),
          reset: () => this._resetMetrics()
        }
      };
    }

    init() {
      if (window.ConfigManager && typeof window.ConfigManager.getConfig === 'function') {
        this.config = {
          ...this.config,
          ...window.ConfigManager.getConfig('airmdnetworkoptimization')
        };
      }

      window.AIRMDNetworkOptimization = this.api;
      
      // ✅ Merged Legacy Compatibility Layer
      this._registerLegacyAliases();
      
      return this.api;
    }
    
    /**
     * Legacy Compatibility Layer - merged from 10-rmd-network-optimization.module.user.js
     * Provides backwards API compatibility for older code
     */
    _registerLegacyAliases() {
      const LEGACY_METHOD_ALIASES = {
        airmdInitNetworkOptimization: "init",
        airmdLazyLoadImages: "lazyLoadImages",
        airmdCompressText: "compressText",
        airmdDecompressText: "decompressText"
      };
      
      Object.entries(LEGACY_METHOD_ALIASES).forEach(([alias, methodName]) => {
        if (!window[alias] && typeof this.api[methodName] === "function") {
          window[alias] = (...args) => this.api[methodName](...args);
        }
      });
      
      console.info("[NetworkOptimization] ✅ Legacy compatibility aliases registered");
    }

    execute() {
      if (this.config.autoOptimize) {
        return this.lazyLoadImages(document);
      }

      // Merged simple functions
      this.lazyLoading();
      this.useCompression();

      return { attached: 0, observer: null };
    }

    onConfigUpdate(settings) {
      Object.assign(this.config, settings);
    }

    loadImage(img) {
      if (!img || typeof img.getAttribute !== 'function') {
        return false;
      }

      const source = img.getAttribute('data-src');
      if (!source) {
        return false;
      }

      img.src = source;
      img.removeAttribute('data-src');
      return true;
    }

    lazyLoadImages(root = document, options = {}) {
      if (!root || typeof root.querySelectorAll !== 'function') {
        return { attached: 0, observer: null };
      }

      const {
        progressive = true,
        adaptive = this.config.adaptiveLoading,
        priority = 'auto'
      } = options;

      const images = Array.from(root.querySelectorAll('img[data-src]'));
      if (images.length === 0) {
        return { attached: 0, observer: null };
      }

      if (!this.config.observeImages || typeof IntersectionObserver !== 'function') {
        images.forEach((img) => this.loadImage(img));
        return { attached: images.length, observer: null };
      }

      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            this._loadImageWithOptimization(entry.target, { progressive, adaptive, priority });
            observer.unobserve(entry.target);
            
            // Cleanup observer when all images are processed
            const remaining = [...observer.takeRecords()].map(r => r.target);
            if (remaining.length === 0) {
              observer.disconnect();
              this._observers.delete(observer);
            }
          }
        });
      }, {
        rootMargin: '50px',
        threshold: 0.1
      });

      images.forEach((img) => observer.observe(img));
      this._observers.add(observer);
      return { attached: images.length, observer };
    }

    _loadImageWithOptimization(img, options = {}) {
      if (!img || typeof img.getAttribute !== 'function') {
        return false;
      }

      const source = img.getAttribute('data-src');
      if (!source) {
        return false;
      }

      // Network-aware loading
      if (options.adaptive && this._isSlowConnection()) {
        const lowQualitySource = img.getAttribute('data-src-low') || this._generateLowQualitySource(source);
        img.src = lowQualitySource;
      } else {
        img.src = source;
      }

      // Progressive enhancement
      if (options.progressive) {
        img.style.transition = 'opacity 0.3s ease-in-out';
        img.style.opacity = '0';

        img.onload = () => {
          img.style.opacity = '1';
        };
      }

      img.removeAttribute('data-src');
      img.removeAttribute('data-src-low');
      return true;
    }

    _generateLowQualitySource(originalSource) {
      // Simple URL manipulation for low quality
      if (originalSource.includes('?')) {
        return originalSource + '&quality=50&format=webp';
      } else {
        return originalSource + '?quality=50&format=webp';
      }
    }

    compressText(text = '') {
      if (window.LZString && typeof window.LZString.compressToUTF16 === 'function') {
        return window.LZString.compressToUTF16(String(text));
      }

      if (window.LZString && typeof window.LZString.compress === 'function') {
        return window.LZString.compress(String(text));
      }

      return String(text);
    }

    decompressText(text = '') {
      if (window.LZString && typeof window.LZString.decompressFromUTF16 === 'function') {
        return window.LZString.decompressFromUTF16(String(text)) || '';
      }

      if (window.LZString && typeof window.LZString.decompress === 'function') {
        return window.LZString.decompress(String(text)) || '';
      }

      return String(text);
    }

    initApi(options = {}) {
      if (options.lazyLoad !== false) {
        this.lazyLoadImages(options.root || document, options);
      }

      // Initialize network detection if enabled
      if (this.config.bandwidthDetection) {
        this._detectBandwidth();
      }

      return {
        compressionAvailable: !!window.LZString,
        observerCount: this._observers.size,
        features: {
          intelligentCaching: this.config.intelligentCaching,
          bandwidthDetection: this.config.bandwidthDetection,
          adaptiveLoading: this.config.adaptiveLoading,
          priorityQueue: this.config.priorityQueue,
          networkAwareness: this.config.networkAwareness
        },
        version: this.version
      };
    }

    destroy() {
      this._observers.forEach((observer) => observer.disconnect());
      this._observers.clear();
      this._clearCache();
      this._clearQueue();
    }

    // Intelligent Caching System
    _setCachedData(key, data, ttl = null) {
      if (!this.config.intelligentCaching) return false;

      const expiration = ttl || this.config.cacheTTL;
      const entry = {
        data,
        timestamp: Date.now(),
        expiration: Date.now() + expiration,
        size: this._estimateSize(data)
      };

      // Check cache size limit
      if (this._getCacheSize() + entry.size > this.config.maxCacheSize * 1024 * 1024) {
        this._evictOldestEntries();
      }

      this._cache.set(key, entry);
      return true;
    }

    _getCachedData(key) {
      if (!this.config.intelligentCaching) return null;

      const entry = this._cache.get(key);
      if (!entry) return null;

      if (Date.now() > entry.expiration) {
        this._cache.delete(key);
        return null;
      }

      this._metrics.cached++;
      return entry.data;
    }

    _clearCache() {
      this._cache.clear();
    }

    _getCacheStats() {
      const size = this._getCacheSize();
      return {
        entries: this._cache.size,
        sizeMB: (size / (1024 * 1024)).toFixed(2),
        maxSizeMB: this.config.maxCacheSize,
        utilization: ((size / (this.config.maxCacheSize * 1024 * 1024)) * 100).toFixed(2) + '%'
      };
    }

    _getCacheSize() {
      let total = 0;
      for (const entry of this._cache.values()) {
        total += entry.size;
      }
      return total;
    }

    _evictOldestEntries() {
      const entries = Array.from(this._cache.entries())
        .sort((a, b) => a[1].timestamp - b[1].timestamp);

      for (const [key] of entries) {
        this._cache.delete(key);
        if (this._getCacheSize() <= this.config.maxCacheSize * 1024 * 1024) break;
      }
    }

    _estimateSize(data) {
      try {
        return new Blob([JSON.stringify(data)]).size;
      } catch {
        return String(data).length * 2; // UTF-16 approximation
      }
    }

    // Bandwidth Detection and Network Awareness
    async _detectBandwidth() {
      if (!this.config.bandwidthDetection) return null;

      const startTime = performance.now();
      try {
        const response = await fetch('https://httpbin.org/bytes/1024000', {
          method: 'GET',
          cache: 'no-cache'
        });

        if (!response.ok) throw new Error('Bandwidth test failed');

        const data = await response.arrayBuffer();
        const endTime = performance.now();
        const duration = (endTime - startTime) / 1000;
        const size = data.byteLength;
        const bandwidth = (size * 8) / duration; // bits per second

        this._bandwidthInfo = {
          bandwidth,
          speed: bandwidth < 1000000 ? 'slow' : bandwidth < 5000000 ? 'medium' : 'fast',
          duration,
          size,
          timestamp: Date.now()
        };

        return this._bandwidthInfo;
      } catch (error) {
        console.warn('Bandwidth detection failed:', error);
        return null;
      }
    }

    _isSlowConnection() {
      if (!this._bandwidthInfo) return navigator.connection?.effectiveType === 'slow-2g' ||
                                    navigator.connection?.effectiveType === '2g' ||
                                    navigator.connection?.effectiveType === '3g';
      return this._bandwidthInfo.speed === 'slow';
    }

    // Enhanced Compression with Multiple Algorithms
    compressText(text = '', algorithm = 'auto') {
      if (!text) return '';

      const originalSize = this._estimateSize(text);
      this._metrics.requests++;
      this._metrics.totalSize += originalSize;

      let compressed;
      let usedAlgorithm = algorithm;

      if (algorithm === 'auto') {
        usedAlgorithm = this._selectBestCompression(text);
      }

      if (this._compressionAlgorithms[usedAlgorithm]) {
        compressed = this._compressionAlgorithms[usedAlgorithm](text);
        this._metrics.compressed++;
        this._metrics.compressedSize += this._estimateSize(compressed);
      } else {
        compressed = text;
      }

      return {
        data: compressed,
        algorithm: usedAlgorithm,
        originalSize,
        compressedSize: this._estimateSize(compressed),
        ratio: originalSize > 0 ? ((originalSize - this._estimateSize(compressed)) / originalSize * 100).toFixed(2) + '%' : '0%'
      };
    }

    decompressText(compressedData, algorithm = 'auto') {
      if (!compressedData) return '';

      if (algorithm === 'auto' && typeof compressedData === 'object') {
        algorithm = compressedData.algorithm || 'lzString';
        compressedData = compressedData.data;
      }

      if (this._compressionAlgorithms[algorithm]) {
        return this._compressionAlgorithms[algorithm](compressedData);
      }

      return compressedData;
    }

    _compressWithLZString(text) {
      if (window.LZString && typeof window.LZString.compressToUTF16 === 'function') {
        return window.LZString.compressToUTF16(String(text));
      }
      return String(text);
    }

    _compressWithBase64(text) {
      try {
        return btoa(unescape(encodeURIComponent(String(text))));
      } catch {
        return String(text);
      }
    }

    _compressWithCustom(text) {
      // Simple custom compression for repetitive patterns
      const str = String(text);
      return str.replace(/(.)\1{2,}/g, (match, char) => `~${char}${match.length}`);
    }

    _selectBestCompression(text) {
      const algorithms = ['lzString', 'base64', 'custom'];
      let bestAlgorithm = 'lzString';
      let bestSize = Infinity;

      for (const algorithm of algorithms) {
        const compressed = this._compressionAlgorithms[algorithm](text);
        const size = this._estimateSize(compressed);
        if (size < bestSize) {
          bestSize = size;
          bestAlgorithm = algorithm;
        }
      }

      return bestAlgorithm;
    }

    _getAvailableCompression() {
      return Object.keys(this._compressionAlgorithms);
    }

    _benchmarkCompression(text) {
      const results = {};
      for (const [name, algorithm] of Object.entries(this._compressionAlgorithms)) {
        const start = performance.now();
        const compressed = algorithm(text);
        const end = performance.now();

        results[name] = {
          time: end - start,
          size: this._estimateSize(compressed),
          ratio: this._estimateSize(text) > 0 ?
            ((this._estimateSize(text) - this._estimateSize(compressed)) / this._estimateSize(text) * 100).toFixed(2) + '%' :
            '0%'
        };
      }
      return results;
    }

    // Request Queuing and Prioritization
    _addToQueue(request) {
      if (!this.config.priorityQueue) {
        this._requestQueue.push(request);
        return this._requestQueue.length;
      }

      // Priority-based insertion
      const priority = request.priority || 0;
      let insertIndex = this._requestQueue.length;

      for (let i = 0; i < this._requestQueue.length; i++) {
        if (this._requestQueue[i].priority < priority) {
          insertIndex = i;
          break;
        }
      }

      this._requestQueue.splice(insertIndex, 0, request);
      return this._requestQueue.length;
    }

    async _processQueue() {
      const results = [];
      while (this._requestQueue.length > 0) {
        const request = this._requestQueue.shift();
        try {
          const result = await this._executeRequest(request);
          results.push({ success: true, result, request });
        } catch (error) {
          results.push({ success: false, error, request });
          this._metrics.failed++;
        }
      }
      return results;
    }

    _clearQueue() {
      this._requestQueue = [];
    }

    async _executeRequest(request) {
      const { url, options = {}, retries = this.config.retryAttempts } = request;

      try {
        const response = await fetch(url, {
          ...options,
          signal: AbortSignal.timeout(30000) // 30 second timeout
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        return await response.json();
      } catch (error) {
        if (retries > 0) {
          await new Promise(resolve => setTimeout(resolve, this.config.retryDelay));
          return this._executeRequest({ ...request, retries: retries - 1 });
        }
        throw error;
      }
    }

    // Performance Monitoring and Metrics
    _getMetrics() {
      return {
        ...this._metrics,
        cache: this._getCacheStats(),
        bandwidth: this._bandwidthInfo,
        compression: {
          efficiency: this._metrics.totalSize > 0 ?
            ((this._metrics.totalSize - this._metrics.compressedSize) / this._metrics.totalSize * 100).toFixed(2) + '%' :
            '0%'
        }
      };
    }

    _resetMetrics() {
      this._metrics = {
        requests: 0,
        cached: 0,
        compressed: 0,
        failed: 0,
        totalSize: 0,
        compressedSize: 0
      };
      this._bandwidthInfo = null;
    }

    // Merged simple functions from second file
    lazyLoading() {
      try {
        console.log("Implementing lazy loading...");
        const images = document.querySelectorAll('img[data-src]');
        if (images.length === 0) return;
        
        const observer = new IntersectionObserver(entries => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              const img = entry.target;
              img.src = img.getAttribute('data-src');
              img.removeAttribute('data-src');
              observer.unobserve(img);
              
              // Cleanup observer when finished
              const remaining = [...observer.takeRecords()].map(r => r.target);
              if (remaining.length === 0) {
                observer.disconnect();
                this._observers.delete(observer);
              }
            }
          });
        });
        
        images.forEach(img => observer.observe(img));
        this._observers.add(observer);
      } catch (error) {
        console.error("Lazy loading error:", error);
      }
    }

    useCompression() {
      try {
        console.log("Using compression techniques...");
        const compressed = LZString.compress("Hello, world!");
        console.log("Compressed data:", compressed);
        const decompressed = LZString.decompress(compressed);
        console.log("Decompressed data:", decompressed);
      } catch (error) {
        console.error("Compression error:", error);
      }
    }
  }

  const instance = new NetworkOptimizationModule();
  window.AIRMDNetworkOptimizationModule = instance;

  let registered = false;

  try {
    if (window.ModuleRegistry && typeof window.ModuleRegistry.register === 'function') {
      window.ModuleRegistry.register(instance);
      registered = true;
    }
  } catch (error) {
    console.warn('[NetworkOptimization] ModuleRegistry registration failed', error);
  }

  if (!registered) {
    try {
      if (window.ChatGPTModules && typeof window.ChatGPTModules.register === 'function') {
        window.ChatGPTModules.register(instance);
        registered = true;
      }
    } catch (error) {
      console.warn('[NetworkOptimization] ChatGPTModules registration failed', error);
    }
  }

  if (!registered) {
    try {
      if (window.ModuleManager && typeof window.ModuleManager.register === 'function') {
        window.ModuleManager.register(instance);
        registered = true;
      }
    } catch (error) {
      console.warn('[NetworkOptimization] ModuleManager registration failed', error);
    }
  }

  if (!registered) {
    instance.init();
    instance.execute();
  }
  console.info(`[NetworkOptimization] Module loaded v${instance.version} - Unified and merged`);})();
